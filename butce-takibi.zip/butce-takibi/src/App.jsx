import { useState, useEffect, useRef } from "react";
import { BudgetDB } from "./lib/db";

// --- Native / AI yapılandırması ---
// AI_PROXY_URL: native (APK) için kendi proxy uç noktan. Boşsa, native'de AI girişleri gizlenir.
// API anahtarını ASLA buraya veya istemciye yazma; anahtar yalnızca proxy sunucusunda durur.
const AI_PROXY_URL = "";
const IS_NATIVE = typeof window !== "undefined" && !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const AI_ENABLED = !IS_NATIVE || !!AI_PROXY_URL;
const AI_ENDPOINT = AI_PROXY_URL || "https://api.anthropic.com/v1/messages";

// Tier 0: native'de sürekli parıltı animasyonlarını kapat (akıcılık)
const REDUCE_FX = IS_NATIVE;

// Tier 2: haptik (yalnızca native; web'de no-op)
let _hap;
const haptic = async (kind = "light") => {
  if (!IS_NATIVE) return;
  try {
    if (!_hap) _hap = await import("@capacitor/haptics");
    const { Haptics, ImpactStyle, NotificationType } = _hap;
    if (kind === "selection") return Haptics.selectionChanged ? Haptics.selectionChanged() : Haptics.impact({ style: ImpactStyle.Light });
    if (kind === "success") return Haptics.notification ? Haptics.notification({ type: NotificationType.Success }) : Haptics.impact({ style: ImpactStyle.Medium });
    const style = kind === "medium" ? ImpactStyle.Medium : kind === "heavy" ? ImpactStyle.Heavy : ImpactStyle.Light;
    return Haptics.impact({ style });
  } catch {}
};

// --- Native servisleri (yalnızca APK; web'de no-op / eksik plugin'de sessiz) ---
// Aylık PDF rapor (jspdf gerektirir; web'de indirir, native'de paylaşır)
async function makeReport(summary) {
  let JsPDF;
  try { const mod = await import("jspdf"); JsPDF = mod.jsPDF || mod.default; } catch { return { ok: false, message: "Rapor için 'jspdf' paketi gerekli (npm i jspdf)." }; }
  try {
    const doc = new JsPDF({ unit: "pt", format: "a4" });
    const L = 48; let y = 64;
    doc.setFontSize(20); doc.text("Bütçe Raporu", L, y); y += 10;
    doc.setFontSize(12); doc.setTextColor(120); doc.text(summary.monthLabel, L, y + 14); y += 44; doc.setTextColor(20);
    const line = (label, val, bold) => { doc.setFont(undefined, bold ? "bold" : "normal"); doc.setFontSize(13); doc.text(label, L, y); doc.text(val, 547 - L, y, { align: "right" }); y += 22; };
    line("Toplam gelir", summary.income, true);
    line("Toplam gider", summary.expense, true);
    line("Net", summary.net, true);
    y += 10; doc.setDrawColor(220); doc.line(L, y, 547 - L, y); y += 24;
    doc.setFontSize(14); doc.setFont(undefined, "bold"); doc.text("Kategori dağılımı", L, y); y += 24;
    doc.setFont(undefined, "normal");
    (summary.rows || []).forEach((r) => { if (y > 760) { doc.addPage(); y = 64; } line(r.label, r.value); });
    const fname = `butce-rapor-${summary.slug}.pdf`;
    if (IS_NATIVE) {
      try {
        const { Filesystem, Directory } = await import("@capacitor/filesystem");
        const { Share } = await import("@capacitor/share");
        const b64 = doc.output("datauristring").split(",")[1];
        const w = await Filesystem.writeFile({ path: fname, data: b64, directory: Directory.Cache });
        try { await Share.share({ title: "Bütçe Raporu", url: w.uri }); } catch {}
        return { ok: true, message: "Rapor oluşturuldu." };
      } catch {}
    }
    doc.save(fname);
    return { ok: true, message: "Rapor indirildi." };
  } catch { return { ok: false, message: "Rapor oluşturulamadı." }; }
}

const BUILTIN_EXP = [
  { key: "market", label: "Market", color: "#0D9488" },
  { key: "yeme", label: "Yeme-İçme", color: "#F59E0B" },
  { key: "ulasim", label: "Ulaşım", color: "#6366F1" },
  { key: "fatura", label: "Faturalar", color: "#EC4899" },
  { key: "eglence", label: "Eğlence", color: "#8B5CF6" },
  { key: "saglik", label: "Sağlık", color: "#10B981" },
  { key: "diger", label: "Diğer", color: "#94A3B8" },
];
const INC_CATS = [
  { key: "maas", label: "Maaş", color: "#16A34A" },
  { key: "ek", label: "Ek Gelir", color: "#0EA5E9" },
  { key: "gelir_diger", label: "Diğer", color: "#94A3B8" },
];
const CAT_PALETTE = ["#0EA5E9", "#F43F5E", "#A855F7", "#22C55E", "#EAB308", "#14B8A6", "#F97316", "#3B82F6", "#EF4444", "#84CC16"];
const MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
const MONTHS_SHORT = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];
const PRIMARY = "#2DE0C0";
const fmt = (n) => new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY", minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n || 0);
// virgül veya nokta ondalık kabul eder ("12,50" -> 12.5)
const parseAmount = (s) => parseFloat(String(s).replace(",", "."));
// çakışmasız id üretici (aynı ms'de bile)
let _uid = 0;
const uid = () => Date.now() * 1000 + (_uid++ % 1000);
const fmtShort = (n) => { const a = Math.abs(n); if (a >= 1000) return (n / 1000).toFixed(a >= 10000 ? 0 : 1).replace(".0", "") + "k"; return String(Math.round(n)); };
const todayISO = () => new Date().toISOString().split("T")[0];
const ymKey = (y, m) => `${y}-${String(m + 1).padStart(2, "0")}`;

// ---- Kredi kartı yardımcıları ----
const cardMonthly = (txn) => Math.round(txn.amount / Math.max(1, txn.installments || 1));
const firstInstallmentYm = (txn, card) => {
  const d = new Date(txn.date);
  let m = d.getMonth();
  if (card && card.statementDay && d.getDate() > card.statementDay) m += 1;
  const dt = new Date(d.getFullYear(), m, 1);
  return { y: dt.getFullYear(), m: dt.getMonth() };
};
const cardTxnPortions = (txn, card) => {
  const n = Math.max(1, txn.installments || 1);
  const per = cardMonthly(txn);
  const f = firstInstallmentYm(txn, card);
  const out = [];
  for (let i = 0; i < n; i++) { const dt = new Date(f.y, f.m + i, 1); out.push({ ym: ymKey(dt.getFullYear(), dt.getMonth()), amount: per, idx: i + 1, total: n }); }
  return out;
};
const cardSummary = (card, txns, paidSet, curYm) => {
  let billed = 0, future = 0, statement = 0;
  txns.filter((t) => t.cardId === card.id).forEach((t) => {
    cardTxnPortions(t, card).forEach((p) => {
      if (p.ym === curYm) statement += p.amount;
      const paid = paidSet.has(card.id + "|" + p.ym);
      if (!paid) { if (p.ym <= curYm) billed += p.amount; else future += p.amount; }
    });
  });
  const debt = billed + future;
  return { billed, future, debt, statement, available: Math.max(0, (card.limit || 0) - debt) };
};
const ACCENTS = {
  mor: { glow: "#7c4dff", from: "rgba(124,77,255,0.32)", to: "rgba(45,24,92,0.55)", solid: "#7c4dff" },
  lacivert: { glow: "#2f6fd6", from: "rgba(47,111,214,0.30)", to: "rgba(15,34,71,0.55)", solid: "#2f6fd6" },
  bordo: { glow: "#c0285a", from: "rgba(192,40,90,0.32)", to: "rgba(90,18,40,0.55)", solid: "#c0285a" },
  teal: { glow: "#12b3a6", from: "rgba(18,179,166,0.30)", to: "rgba(8,60,56,0.55)", solid: "#12b3a6" },
  amber: { glow: "#e0922f", from: "rgba(224,146,47,0.30)", to: "rgba(92,55,12,0.55)", solid: "#e0922f" },
};
const ACCENT_KEYS = ["mor", "lacivert", "bordo", "teal", "amber"];
const CARD_SHELL = {
  position: "relative", borderRadius: 24, overflow: "hidden", color: "#fff",
  background: "radial-gradient(120% 80% at 15% -5%, #1a2247 0%, rgba(26,34,71,0) 55%), radial-gradient(120% 70% at 95% 8%, #4a1730 0%, rgba(74,23,48,0) 50%), radial-gradient(110% 60% at 50% 110%, #122036 0%, rgba(18,32,54,0) 60%), #07080d",
};
const cardSkin = (accentKey, radius = 24) => {
  const a = ACCENTS[accentKey] || ACCENTS.mor;
  return {
    a,
    wrap: { position: "relative", borderRadius: radius, padding: 22, overflow: "hidden", color: "#fff", background: `linear-gradient(150deg, ${a.from} 0%, ${a.to} 100%), rgba(255,255,255,0.04)`, border: "1px solid rgba(255,255,255,0.14)", backdropFilter: "blur(22px)", WebkitBackdropFilter: "blur(22px)", boxShadow: "0 18px 40px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.18)" },
    glow: { position: "absolute", top: -50, right: -30, width: 200, height: 200, borderRadius: "50%", background: a.glow, filter: "blur(70px)", opacity: 0.45, pointerEvents: "none" },
    sheen: { position: "absolute", inset: 0, borderRadius: radius, background: "linear-gradient(180deg, rgba(255,255,255,0.10) 0%, rgba(255,255,255,0) 28%)", pointerEvents: "none" },
    chipWrap: { width: 40, height: 40, borderRadius: 11, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.18)", flexShrink: 0 },
    chipInner: { width: 18, height: 13, borderRadius: 3, background: "linear-gradient(135deg,#f7e3a1,#d4a843)", boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.12)" },
  };
};
const glassInput = { width: "100%", padding: 14, borderRadius: 14, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#fff", fontSize: 15, fontWeight: 600, fontFamily: "inherit", outline: "none", boxSizing: "border-box" };


const mkTheme = (fg, bgRgb, cardSolid, overlay) => ({
  "--fg": fg, "--bg-rgb": bgRgb, "--bg": `rgb(${bgRgb})`,
  "--card": `rgba(${fg},0.045)`, "--card2": `rgba(${fg},0.06)`, "--chip": `rgba(${fg},0.08)`,
  "--text": `rgb(${fg})`, "--sub": `rgba(${fg},0.62)`, "--muted": `rgba(${fg},0.42)`,
  "--line": `rgba(${fg},0.10)`, "--border": `rgba(${fg},0.10)`, "--navbg": `rgba(${bgRgb},0.9)`,
  "--dash": `rgba(${fg},0.16)`, "--addDash": "rgba(45,224,192,0.5)", "--overlay": overlay, "--card-solid": cardSolid,
  "--cardShadow": "0 10px 30px -16px rgba(0,0,0,0.25)", "--cardShadowSm": "0 6px 18px -10px rgba(0,0,0,0.2)",
});
const THEMES = {
  dark: mkTheme("255,255,255", "7,8,16", "#0c0e1a", "rgba(4,5,12,.7)"),
  light: mkTheme("20,22,43", "244,246,251", "#ffffff", "rgba(18,21,42,.45)"),
};

const KEYFRAMES = `
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap');
@keyframes bt-tile-in{0%{transform:scale(.55) rotate(-14deg);opacity:0}60%{transform:scale(1.08) rotate(3deg);opacity:1}100%{transform:scale(1) rotate(0);opacity:1}}
@keyframes bt-bar{0%{transform:scaleY(.06)}100%{transform:scaleY(1)}}
@keyframes bt-ring{0%{transform:scale(.5);opacity:.55}80%{opacity:0}100%{transform:scale(2.1);opacity:0}}
@keyframes bt-rise{0%{transform:translateY(16px);opacity:0}100%{transform:translateY(0);opacity:1}}
@keyframes bt-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-14px)}}
@keyframes bt-glow{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(2%,-3%) scale(1.06)}}
@keyframes bt-pulse{0%,100%{opacity:.55}50%{opacity:1}}
@keyframes bt-coin{0%{transform:translateY(-6px) rotate(-20deg);opacity:0}55%{transform:translateY(0) rotate(6deg);opacity:1}100%{transform:translateY(0) rotate(0);opacity:1}}
@keyframes bt-sheet{0%{transform:translateY(40px);opacity:0}100%{transform:translateY(0);opacity:1}}
@keyframes bt-toast{0%{transform:translateY(20px);opacity:0}100%{transform:translateY(0);opacity:1}}
@keyframes bt-pulse{0%,100%{opacity:.55}50%{opacity:1}}
@keyframes bt-sp-tile{0%{opacity:0;transform:scale(.55) translateY(16px)}55%{opacity:1}100%{opacity:1;transform:scale(1) translateY(0)}}
@keyframes bt-sp-coin{0%{opacity:0;transform:scale(0) rotate(-40deg)}65%{opacity:1;transform:scale(1.18) rotate(8deg)}100%{opacity:1;transform:scale(1) rotate(0)}}
@keyframes bt-sp-ring{0%{transform:scale(.85);opacity:.5}100%{transform:scale(2.5);opacity:0}}
@keyframes bt-sp-bar{0%{transform:scaleY(0)}100%{transform:scaleY(1)}}
@keyframes bt-sp-up{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
@keyframes bt-sp-prog{from{width:0}to{width:100%}}
@keyframes bt-sp-tap{0%,100%{opacity:.35}50%{opacity:.9}}
@keyframes bt-view{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion: reduce){.bt-app *{animation-duration:.001ms !important;animation-iteration-count:1 !important;transition-duration:.001ms !important}}
@media print{body *{visibility:hidden !important}#bt-print,#bt-print *{visibility:visible !important}#bt-print{position:absolute !important;left:0;top:0;width:100%;padding:24px;background:#fff !important}#bt-print *{color:#111 !important}}
.bt-app *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
.bt-app .num{font-family:'Space Grotesk','Manrope',system-ui,sans-serif}
.bt-app input::placeholder,.bt-app textarea::placeholder{color:var(--muted)}
.bt-app input[type=date]::-webkit-calendar-picker-indicator{opacity:.5;cursor:pointer}
.bt-app button{transition:transform .08s ease, filter .15s ease}
.bt-app button:active{transform:scale(.96)}
.bt-app .bt-row:active{filter:brightness(1.08)}
`;

const cardBox = (extra) => ({ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 20, padding: 18, boxShadow: "var(--cardShadow)", ...extra });
const fieldStyle = { width: "100%", background: "var(--card2)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 14, padding: "13px 15px", fontSize: 15, outline: "none", fontFamily: "inherit" };


export default function App() {
  const dbRef = useRef(null);
  const [view, setView] = useState("ozet");
  const [theme, setThemeState] = useState("dark");
  const [booting, setBooting] = useState(true);
  const [leaving, setLeaving] = useState(false);

  const [tx, setTx] = useState([]);
  const [budgets, setBudgets] = useState({});
  const [recurring, setRecurring] = useState([]);
  const [customCats, setCustomCats] = useState([]);
  const [goals, setGoals] = useState([]);
  const [cards, setCards] = useState([]);
  const [cardTxns, setCardTxns] = useState([]);
  const [cardPaid, setCardPaid] = useState([]);
  const [editing, setEditing] = useState(null);
  const [drillCat, setDrillCat] = useState(null);
  const [lastDeleted, setLastDeleted] = useState(null);
  const [onboard, setOnboard] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const [ai, setAi] = useState(false);
  const [bioOn, setBioOn] = useState(() => { try { return localStorage.getItem("bt-biolock") === "1"; } catch { return false; } });
  const [locked, setLocked] = useState(() => { try { return IS_NATIVE && localStorage.getItem("bt-biolock") === "1"; } catch { return false; } });
  const undoTimer = useRef(null);
  const now = new Date();
  const [ym, setYm] = useState({ y: now.getFullYear(), m: now.getMonth() });

  const setTheme = (t) => { setThemeState(t); try { localStorage.setItem("bt-theme", t); } catch {} };
  const finishSetup = () => { setOnboard(false); try { localStorage.setItem("bt-setup-done", "1"); } catch {} };

  const loadAll = async () => {
    const db = dbRef.current;
    const [t, b, r, g, cc, cd, ct, cp] = await Promise.all([
      db.getAllTransactions(), db.getAllBudgets(), db.getRecurring(), db.getGoals(),
      db.getCustomCats(), db.getCards(), db.getCardTxns(), db.getCardPaid(),
    ]);
    setTx(t); setBudgets(b); setRecurring(r); setGoals(g); setCustomCats(cc);
    setCards(cd); setCardTxns(ct); setCardPaid(cp);
    return t;
  };

  useEffect(() => {
    try { const sv = localStorage.getItem("bt-theme"); if (sv) setThemeState(sv); } catch {}
    (async () => {
      const db = new BudgetDB();
      await db.init();
      dbRef.current = db;
      await loadAll();
      try { if (!localStorage.getItem("bt-setup-done")) setOnboard(true); } catch { setOnboard(true); }
    })();
    const t1 = setTimeout(() => setLeaving(true), 3000);
    const t2 = setTimeout(() => setBooting(false), 3000 + 520);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  // Geri tuşu için güncel UI durumunu tutan ref (kapalı closure'dan kaçınmak için)
  const uiRef = useRef({});
  uiRef.current = { view, setView, ai, setAi, editing, setEditing, drillCat, setDrillCat, onboard, confirm, setConfirm, finishSetup };
  const bioRef = useRef(bioOn); bioRef.current = bioOn;
  const dataRef = useRef(null); dataRef.current = { transactions: tx, budgets, recurring, customCats, goals, cards, cardTxns, cardPaid, exportDate: new Date().toISOString(), version: 4 };
  const dueRef = useRef([]);

  const bioVerify = async () => {
    try {
      const m = await import("capacitor-native-biometric").catch(() => null);
      if (!m || !m.NativeBiometric) return true;
      const avail = await m.NativeBiometric.isAvailable();
      if (!avail || !avail.isAvailable) return true; // cihaz desteklemiyorsa kilit yok
      await m.NativeBiometric.verifyIdentity({ reason: "Bütçe Takibi'ni aç", title: "Kimlik doğrulama", subtitle: "", description: "" });
      return true;
    } catch { return false; }
  };
  const tryUnlock = async () => { const ok = await bioVerify(); if (ok) setLocked(false); };
  const toggleBio = async () => {
    if (bioOn) { setBioOn(false); try { localStorage.setItem("bt-biolock", "0"); } catch {} return; }
    const ok = await bioVerify();
    if (ok) { setBioOn(true); try { localStorage.setItem("bt-biolock", "1"); } catch {} }
  };
  const fsBackup = async () => {
    if (!IS_NATIVE) return;
    try {
      const { Filesystem, Directory, Encoding } = await import("@capacitor/filesystem");
      await Filesystem.writeFile({ path: "butce-autobackup.json", data: JSON.stringify(dataRef.current), directory: Directory.Data, encoding: Encoding.UTF8 });
    } catch {}
  };

  // Native başlatma (yalnızca APK/WebView'de çalışır; web'de no-op)
  useEffect(() => {
    if (!IS_NATIVE) return;
    let backHandle;
    (async () => {
      try { const { SplashScreen } = await import("@capacitor/splash-screen"); await SplashScreen.hide(); } catch {}
      try {
        const { App: CapApp } = await import("@capacitor/app");
        backHandle = await CapApp.addListener("backButton", ({ canGoBack }) => {
          const u = uiRef.current;
          if (u.confirm) return u.setConfirm(null);
          if (u.ai) return u.setAi(false);
          if (u.editing) return u.setEditing(null);
          if (u.drillCat) return u.setDrillCat(null);
          if (u.onboard) return u.finishSetup();
          if (u.view !== "ozet") return u.setView("ozet");
          CapApp.exitApp();
        });
      } catch {}
    })();
    return () => { try { backHandle && backHandle.remove(); } catch {} };
  }, []);

  // Durum çubuğunu temaya göre boya (native)
  useEffect(() => {
    if (!IS_NATIVE) return;
    (async () => {
      try {
        const { StatusBar, Style } = await import("@capacitor/status-bar");
        const dark = theme === "dark";
        await StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light });
        try { await StatusBar.setBackgroundColor({ color: dark ? "#070810" : "#F4F6FB" }); } catch {}
      } catch {}
    })();
  }, [theme]);

  // Biyometrik kilit: splash bitince doğrula; arka plandan dönünce kilitle + arka plana geçince dosya yedeği
  useEffect(() => { if (!booting && locked && IS_NATIVE) tryUnlock(); }, [booting, locked]);
  useEffect(() => {
    if (!IS_NATIVE) return;
    let h;
    (async () => {
      try {
        const { App: CapApp } = await import("@capacitor/app");
        h = await CapApp.addListener("appStateChange", ({ isActive }) => {
          if (!isActive) { fsBackup(); if (bioRef.current) setLocked(true); }
        });
      } catch {}
    })();
    return () => { try { h && h.remove(); } catch {} };
  }, []);

  // Yerel bildirimler: yedek hatırlatması + fatura vadeleri
  useEffect(() => {
    if (!IS_NATIVE) return;
    (async () => {
      try {
        const { LocalNotifications } = await import("@capacitor/local-notifications");
        const perm = await LocalNotifications.requestPermissions();
        if (perm.display !== "granted") return;
        const notifs = [];
        let last = 0; try { last = Number(localStorage.getItem("bt-last-backup")) || 0; } catch {}
        if (!last || Date.now() - last > 7 * 86400000) notifs.push({ id: 9001, title: "Yedek hatırlatması", body: "Bir süredir yedek almadın. Ayarlar → Yedek'ten dışa aktar.", schedule: { at: new Date(Date.now() + 8 * 3600000) } });
        const now = new Date();
        (dueRef.current || []).forEach((r) => {
          if (r.active === false || r.paid) return;
          const d = new Date(now.getFullYear(), now.getMonth(), r.day, 9, 0, 0);
          if (d.getTime() > Date.now()) notifs.push({ id: 9100 + (Number(r.id) % 800), title: "Fatura hatırlatması", body: `${r.name} — ${fmt(r.amount)} (vade ${r.day})`, schedule: { at: d } });
        });
        if (notifs.length) { try { await LocalNotifications.cancel({ notifications: notifs.map((n) => ({ id: n.id })) }); } catch {} await LocalNotifications.schedule({ notifications: notifs }); }
      } catch {}
    })();
  }, [recurring, tx.length, cards.length]);

  const expCats = [...BUILTIN_EXP, ...customCats];
  const allCats = [...expCats, ...INC_CATS];
  const catOf = (k) => allCats.find((c) => c.key === k) || BUILTIN_EXP[6];

  const first = new Date(ym.y, ym.m, 1).toISOString().split("T")[0];
  const last = new Date(ym.y, ym.m + 1, 0).toISOString().split("T")[0];
  const monthTx = tx.filter((t) => t.date >= first && t.date <= last);
  const expenses = monthTx.filter((t) => t.type === "expense");
  const totalExpense = expenses.reduce((a, t) => a + t.amount, 0);
  const totalIncome = monthTx.filter((t) => t.type === "income").reduce((a, t) => a + t.amount, 0);
  const net = totalIncome - totalExpense;

  const map = {};
  expenses.forEach((t) => (map[t.category] = (map[t.category] || 0) + t.amount));
  const byCat = expCats.map((c) => ({ ...c, value: map[c.key] || 0 })).filter((c) => c.value > 0).sort((a, b) => b.value - a.value);
  const donutTotal = byCat.reduce((a, c) => a + c.value, 0) || 1;
  let acc = 0;
  const donutBg = byCat.length ? `conic-gradient(${byCat.map((c) => { const st = (acc / donutTotal) * 360; acc += c.value; return `${c.color} ${st}deg ${(acc / donutTotal) * 360}deg`; }).join(", ")})` : "var(--line)";

  const totalBudget = Object.values(budgets).reduce((a, v) => a + v, 0);
  const pct = totalBudget ? Math.min(100, (totalExpense / totalBudget) * 100) : 0;
  const over = !!totalBudget && totalExpense > totalBudget;

  const isCurrentMonth = ym.y === now.getFullYear() && ym.m === now.getMonth();
  const daysInMonth = new Date(ym.y, ym.m + 1, 0).getDate();
  const dayNow = isCurrentMonth ? now.getDate() : daysInMonth;
  const projected = isCurrentMonth && dayNow > 0 ? Math.round((totalExpense / dayNow) * daysInMonth) : null;
  const remainingDays = Math.max(1, daysInMonth - dayNow + 1);
  const dailyLeft = totalBudget > 0 && isCurrentMonth ? Math.round((totalBudget - totalExpense) / remainingDays) : null;
  const overCats = expCats.filter((c) => budgets[c.key] && (map[c.key] || 0) > budgets[c.key]);

  // ---- IndexedDB destekli aksiyonlar (mutasyon -> db -> loadAll) ----
  const addTx = async (t) => { await dbRef.current.addTransaction(t); await loadAll(); haptic("success"); };
  const updateTx = async (id, patch) => { await dbRef.current.updateTransaction(id, patch); await loadAll(); };
  const delTx = async (id) => {
    const t = tx.find((x) => x.id === id);
    await dbRef.current.deleteTransaction(id);
    await loadAll();
    if (t) { haptic("light"); setLastDeleted(t); clearTimeout(undoTimer.current); undoTimer.current = setTimeout(() => setLastDeleted(null), 4500); }
  };
  const undoDelete = async () => { if (lastDeleted) { await dbRef.current.addTransaction(lastDeleted); setLastDeleted(null); clearTimeout(undoTimer.current); await loadAll(); } };
  const setLimit = async (cat, val) => { const n = parseAmount(val); if (!n || n <= 0) await dbRef.current.deleteBudget(cat); else await dbRef.current.updateBudget(cat, n); await loadAll(); };
  const suggestBudgets = async () => {
    const ks = [0, 1, 2].map((i) => { const d = new Date(ym.y, ym.m - i, 1); return ymKey(d.getFullYear(), d.getMonth()); });
    const sums = {};
    tx.filter((t) => t.type === "expense").forEach((t) => { if (ks.includes((t.date || "").slice(0, 7))) sums[t.category] = (sums[t.category] || 0) + t.amount; });
    const next = {};
    Object.entries(sums).forEach(([k, v]) => { const avg = v / 3; if (avg > 0) next[k] = Math.max(100, Math.ceil(avg / 100) * 100); });
    await dbRef.current.replaceBudgets(next); await loadAll();
  };
  const askSuggest = () => setConfirm({ text: "Tüm limitler son 3 ayın kategori ortalamasına göre yeniden yazılacak. Devam edilsin mi?", onYes: suggestBudgets, yesLabel: "Uygula", danger: false });
  const addRecurring = async (r) => { await dbRef.current.addRecurring(r); await loadAll(); };
  const updRecurring = async (r) => { await dbRef.current.updateRecurring(r); await loadAll(); };
  const delRecurring = async (id) => { await dbRef.current.deleteRecurring(id); await loadAll(); };
  const payRecurring = async (r) => { const date = `${ymKey(ym.y, ym.m)}-${String(r.day).padStart(2, "0")}`; await addTx({ type: r.type || "expense", date, amount: r.amount, category: r.category, description: r.name, recurringId: r.id }); };
  const addCat = async (label, color) => { await dbRef.current.addCustomCat({ key: "custom_" + uid(), label, color }); await loadAll(); };
  const delCat = async (key) => { await dbRef.current.deleteCustomCat(key); await loadAll(); };
  const addGoal = async (name, target, color) => { await dbRef.current.addGoal({ name, target, saved: 0, color }); await loadAll(); };
  const contributeGoal = async (id, amount) => { const g = goals.find((x) => x.id === id); if (g) { await dbRef.current.updateGoal({ ...g, saved: Math.max(0, g.saved + amount) }); await loadAll(); haptic("light"); } };
  const delGoal = async (id) => { await dbRef.current.deleteGoal(id); await loadAll(); };
  const addCard = async (c) => { await dbRef.current.addCard({ ...c, id: uid() }); await loadAll(); };
  const delCard = async (id) => { await dbRef.current.deleteCard(id); await loadAll(); };
  const addCardTxn = async (t) => { await dbRef.current.addCardTxn({ ...t, id: uid() }); await loadAll(); haptic("success"); };
  const delCardTxn = async (id) => { await dbRef.current.deleteCardTxn(id); await loadAll(); };
  const payStatement = async (cardId, ymk) => { await dbRef.current.toggleCardPaid(cardId, ymk); await loadAll(); haptic("medium"); };
  // yıkıcı işlemler için onay
  const askDelRecurring = (id) => setConfirm({ text: "Bu tekrar eden kaydı silmek istediğine emin misin?", onYes: () => delRecurring(id) });
  const askDelGoal = (id) => setConfirm({ text: "Bu hedefi silmek istediğine emin misin?", onYes: () => delGoal(id) });
  const askDelCat = (key) => { const n = tx.filter((t) => t.category === key).length; setConfirm({ text: n ? `Bu kategori silinsin mi? Bu kategorideki ${n} işlem "Diğer" olarak görünecek.` : "Bu kategori silinsin mi?", onYes: () => delCat(key) }); };
  const askDelCard = (id) => setConfirm({ text: "Bu kart ve tüm işlemleri silinsin mi?", onYes: () => delCard(id) });
  const onImport = async (text) => { await dbRef.current.importJSON(text); await loadAll(); };
  const exportData = { transactions: tx, budgets, recurring, customCats, goals, cards, cardTxns, cardPaid };

  // --- Native: aylık PDF rapor (yeni) ---
  const onReport = () => makeReport({ monthLabel: `${MONTHS[ym.m]} ${ym.y}`, slug: ymKey(ym.y, ym.m), income: fmt(totalIncome), expense: fmt(totalExpense), net: fmt(net), rows: byCat.map((c) => ({ label: c.label, value: fmt(c.value) })) });

  const sv = (v) => { haptic("selection"); setView(v); };
  const shiftMonth = (d) => setYm((p) => { const dt = new Date(p.y, p.m + d, 1); return { y: dt.getFullYear(), m: dt.getMonth() }; });
  const dueRecurring = recurring.map((r) => ({ ...r, paid: !!tx.find((t) => t.recurringId === r.id && (t.date || "").startsWith(ymKey(ym.y, ym.m))) }));
  dueRef.current = dueRecurring;

  const drillTx = drillCat ? monthTx.filter((t) => t.category === drillCat).sort((a, b) => (b.date < a.date ? -1 : 1)) : [];

  return (
    <div className="bt-app" style={{ ...THEMES[theme], minHeight: "100vh", background: "var(--bg)", color: "var(--text)", display: "flex", justifyContent: "center", fontFamily: "'Manrope', system-ui, -apple-system, sans-serif", transition: "background .35s ease" }}>
      <style>{KEYFRAMES}</style>
      <div style={{ width: "100%", maxWidth: 440, position: "relative", display: "flex", flexDirection: "column", minHeight: "100vh", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 0 }}>
          <div style={{ position: "absolute", top: "-12%", left: "-18%", width: "70%", height: "42%", background: "radial-gradient(circle, rgba(45,224,192,.30), transparent 68%)", filter: "blur(38px)", animation: REDUCE_FX ? "none" : "bt-glow 14s ease-in-out infinite" }} />
          <div style={{ position: "absolute", top: "8%", right: "-22%", width: "72%", height: "46%", background: "radial-gradient(circle, rgba(139,123,255,.28), transparent 68%)", filter: "blur(42px)", animation: REDUCE_FX ? "none" : "bt-glow 18s ease-in-out infinite reverse" }} />
          <div style={{ position: "absolute", bottom: "-14%", left: "20%", width: "64%", height: "40%", background: "radial-gradient(circle, rgba(56,189,248,.18), transparent 70%)", filter: "blur(46px)", animation: REDUCE_FX ? "none" : "bt-glow 20s ease-in-out infinite" }} />
        </div>
        <div style={{ position: "relative", zIndex: 1, flexShrink: 0, padding: "18px 20px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 12, letterSpacing: ".04em", color: "var(--muted)", fontWeight: 600, textTransform: "uppercase" }}>{(() => { const h = new Date().getHours(); return h < 6 ? "İyi geceler" : h < 12 ? "Günaydın" : h < 18 ? "İyi günler" : "İyi akşamlar"; })()}</div>
            <div className="num" style={{ fontSize: 20, fontWeight: 700, color: "#fff", letterSpacing: "-.01em", marginTop: 2 }}>Cüzdanım</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="Tema" style={{ width: 40, height: 40, borderRadius: 13, flexShrink: 0, background: "var(--card)", border: "1px solid var(--border)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--sub)" }}>
              <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9"><circle cx="12" cy="12" r="9" /><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" stroke="none" /></svg>
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--card)", border: "1px solid var(--border)", borderRadius: 14, padding: "6px 8px" }}>
              <RoundBtn onClick={() => shiftMonth(-1)}><Chevron dir="left" /></RoundBtn>
              <div style={{ fontSize: 13, fontWeight: 700, minWidth: 86, textAlign: "center", letterSpacing: "-.01em" }}>{MONTHS_SHORT[ym.m]} {ym.y}</div>
              <RoundBtn onClick={() => shiftMonth(1)}><Chevron dir="right" /></RoundBtn>
            </div>
          </div>
        </div>

        <main style={{ position: "relative", zIndex: 1, flex: 1, overflowY: "auto", overflowX: "hidden", padding: "6px 18px 120px" }}>
          <div key={view} style={{ animation: "bt-view .32s ease both" }}>
          {view === "ozet" && <Ozet {...{ net, totalIncome, totalExpense, totalBudget, pct, over, donutBg, byCat, monthTx, catOf, onEdit: setEditing, goAll: () => sv("islemler"), projected, dailyLeft, overCats, tx, ym, goals, onAddGoal: addGoal, onContribute: contributeGoal, onDelGoal: askDelGoal, onDrill: setDrillCat, cards, cardTxns, cardPaid, onAddCard: addCard, onAddCardTxn: addCardTxn, onDelCardTxn: delCardTxn, onPayStatement: payStatement, onDelCard: askDelCard }} />}
          {view === "islemler" && <Islemler monthTx={monthTx} allTx={tx} catOf={catOf} onEdit={setEditing} onDel={delTx} />}
          {view === "ekle" && <Ekle expCats={expCats} catOf={catOf} tx={tx} onAdd={addTx} onDone={() => sv("ozet")} onOpenAI={() => setAi(true)} />}
          {view === "faturalar" && <Faturalar recurring={recurring} due={dueRecurring} expCats={expCats} catOf={catOf} onAdd={addRecurring} onUpdate={updRecurring} onRemove={askDelRecurring} onPay={payRecurring} />}
          {view === "ayarlar" && <Ayarlar {...{ theme, setTheme, budgets, onSetLimit: setLimit, byCatMap: map, expCats, customCats, onAddCat: addCat, onDelCat: askDelCat, onSuggest: askSuggest, exportData, onImport, onReplayOnboard: () => setOnboard(true), bioOn, onToggleBio: toggleBio, onReport }} />}
          </div>
        </main>

        <nav style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 440, background: "var(--navbg)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", borderTop: "1px solid var(--line)", padding: "9px 14px calc(24px + env(safe-area-inset-bottom))", display: "flex", alignItems: "flex-end", gap: 2, boxShadow: "0 -6px 24px rgba(16,24,40,.05)", zIndex: 20 }}>
          <NavItem active={view === "ozet"} onClick={() => sv("ozet")} label="Özet" icon={<svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="3.4" /></svg>} />
          <NavItem active={view === "islemler"} onClick={() => sv("islemler")} label="İşlemler" icon={<svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><line x1="4" y1="7" x2="20" y2="7" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="17" x2="14" y2="17" /></svg>} />
          <button onClick={() => sv("ekle")} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, background: "transparent", border: "none", cursor: "pointer", padding: 0, fontFamily: "inherit" }}>
            <div style={{ width: 50, height: 50, borderRadius: 17, background: "linear-gradient(150deg,#2DE0C0,#1c9d88)", display: "flex", alignItems: "center", justifyContent: "center", marginTop: -20, boxShadow: "0 12px 26px -6px rgba(45,224,192,.6)" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
            </div>
            <span style={{ fontSize: 10.5, fontWeight: 600, color: view === "ekle" ? PRIMARY : "var(--muted)" }}>Ekle</span>
          </button>
          <NavItem active={view === "faturalar"} onClick={() => sv("faturalar")} label="Faturalar" icon={<svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><polyline points="17 1.8 21 5.8 17 9.8" /><path d="M3 11V9.5a4 4 0 0 1 4-4h14" /><polyline points="7 22.2 3 18.2 7 14.2" /><path d="M21 13v1.5a4 4 0 0 1-4 4H3" /></svg>} />
          <NavItem active={view === "ayarlar"} onClick={() => sv("ayarlar")} label="Ayarlar" icon={<svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><line x1="4" y1="8" x2="20" y2="8" /><line x1="4" y1="16" x2="20" y2="16" /><circle cx="9" cy="8" r="2.4" fill="currentColor" /><circle cx="15" cy="16" r="2.4" fill="currentColor" /></svg>} />
        </nav>

        {lastDeleted && (
          <div style={{ position: "fixed", bottom: 96, left: "50%", transform: "translateX(-50%)", width: "calc(100% - 36px)", maxWidth: 404, background: "#0F172A", color: "#fff", borderRadius: 14, padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", zIndex: 40, boxShadow: "0 12px 30px -8px rgba(0,0,0,.5)", animation: "bt-toast .25s ease both" }}>
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>İşlem silindi</span>
            <button onClick={undoDelete} style={{ background: "transparent", border: "none", color: "#5EEAD4", fontSize: 13.5, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>GERİ AL</button>
          </div>
        )}

        {drillCat && <DrillSheet cat={catOf(drillCat)} list={drillTx} onClose={() => setDrillCat(null)} onEdit={(t) => { setDrillCat(null); setEditing(t); }} />}
        {editing && <EditSheet tx={editing} expCats={expCats} onClose={() => setEditing(null)} onSave={(patch) => { updateTx(editing.id, patch); setEditing(null); }} onDelete={() => { delTx(editing.id); setEditing(null); }} />}
        {onboard && <Onboard onClose={finishSetup} onFinish={async (income, b) => { if (income > 0) await addTx({ type: "income", amount: income, category: "maas", description: "Aylık gelir", date: todayISO() }); if (b && Object.keys(b).length) { for (const [k, v] of Object.entries(b)) await dbRef.current.updateBudget(k, v); await loadAll(); } finishSetup(); }} />}
        {confirm && <ConfirmSheet text={confirm.text} yesLabel={confirm.yesLabel} danger={confirm.danger !== false} onClose={() => setConfirm(null)} onYes={() => { confirm.onYes(); setConfirm(null); }} />}
        {ai && <AISheet expCats={expCats} catOf={catOf} onAdd={addTx} onClose={() => setAi(false)} />}
        {locked && <LockScreen onUnlock={tryUnlock} />}
        {booting && <Splash leaving={leaving} onSkip={() => { setLeaving(true); setTimeout(() => setBooting(false), 300); }} />}
      </div>
    </div>
  );
}

function RoundBtn({ children, onClick }) {
  return <button onClick={onClick} style={{ width: 32, height: 32, borderRadius: 11, background: "var(--card)", border: "1px solid var(--border)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--sub)", boxShadow: "0 1px 2px rgba(16,24,40,.04)" }}>{children}</button>;
}
function Chevron({ dir }) { return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points={dir === "left" ? "15 18 9 12 15 6" : "9 18 15 12 9 6"} /></svg>; }
function NavItem({ active, onClick, label, icon }) {
  return <button onClick={onClick} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, background: "transparent", border: "none", cursor: "pointer", padding: "6px 0", color: active ? PRIMARY : "var(--muted)", fontFamily: "inherit" }}>{icon}<span style={{ fontSize: 10.5, fontWeight: 600 }}>{label}</span></button>;
}
function Seg({ options, value, onChange, sm }) {
  return <div style={{ display: "flex", gap: 6, background: "var(--card)", padding: 5, borderRadius: 16, boxShadow: "var(--cardShadowSm)" }}>{options.map(([k, l]) => <button key={k} onClick={() => onChange(k)} style={{ flex: 1, padding: sm ? 8 : 11, borderRadius: 11, border: "none", cursor: "pointer", fontWeight: 700, fontSize: sm ? 12 : 13.5, fontFamily: "inherit", background: value === k ? PRIMARY : "transparent", color: value === k ? "#fff" : "var(--sub)" }}>{l}</button>)}</div>;
}
function Chip({ label, active, color, onClick, small }) {
  return <button onClick={onClick} style={{ background: active ? color : "var(--chip)", color: active ? "#fff" : "var(--sub)", border: "none", borderRadius: 999, padding: small ? "8px 13px" : "9px 15px", fontSize: small ? 12.5 : 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>{label}</button>;
}
function Sheet({ title, onClose, children }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 60, background: "var(--overlay)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 440, background: "var(--bg)", borderRadius: "24px 24px 0 0", padding: "10px 18px 26px", maxHeight: "88vh", overflowY: "auto", animation: "bt-sheet .28s cubic-bezier(.2,.8,.2,1) both" }}>
        <div style={{ width: 40, height: 4, borderRadius: 999, background: "var(--border)", margin: "4px auto 14px" }} />
        {title && <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 12 }}>{title}</div>}
        {children}
      </div>
    </div>
  );
}

// ---------- ÖZET ----------
function Ozet(props) {
  const { net, totalIncome, totalExpense, totalBudget, pct, over, donutBg, byCat, monthTx, catOf, onEdit, goAll, projected, dailyLeft, overCats, tx, ym, goals, onAddGoal, onContribute, onDelGoal, onDrill, cards, cardTxns, cardPaid, onAddCard, onAddCardTxn, onDelCardTxn, onPayStatement, onDelCard } = props;
  const [tab, setTab] = useState("ay");
  const [report, setReport] = useState(false);
  const budgetMsg = !totalBudget ? "" : over ? `${fmt(totalExpense - totalBudget)} aşıldı` : `${fmt(totalBudget - totalExpense)} kaldı`;

  // bütçe sağlık skoru (0-100): tasarruf oranı + bütçe uyumu
  const savingsRate = totalIncome > 0 ? net / totalIncome : 0;
  const saveScore = Math.max(0, Math.min(50, (savingsRate / 0.3) * 50));
  let budgetScore;
  if (!totalBudget) budgetScore = 30;
  else { const u = totalExpense / totalBudget; budgetScore = u <= 1 ? 50 - u * 10 : Math.max(0, 40 - (u - 1) * 80); }
  const health = Math.round(Math.max(0, Math.min(100, saveScore + budgetScore)));
  const healthColor = health >= 75 ? "#16A34A" : health >= 50 ? "#F59E0B" : "#E11D48";
  const healthLabel = health >= 75 ? "İyi" : health >= 50 ? "Orta" : "Dikkat";
  const healthNote = savingsRate < 0 ? "Bu ay giderin gelirini aştı" : over ? "Bütçe limitini aştın" : savingsRate >= 0.2 ? "Güzel tasarruf ediyorsun" : "Dengeli görünüyor";

  // ödeme dağılımı (gider)
  const pay = { kart: 0, nakit: 0 };
  monthTx.filter((t) => t.type === "expense").forEach((t) => { pay[t.method === "nakit" ? "nakit" : "kart"] += t.amount; });
  const payTotal = pay.kart + pay.nakit;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <Seg sm options={[["ay", "Bu Ay"], ["trend", "Trend"], ["hedef", "Hedefler"], ["kart", "Kart"]]} value={tab} onChange={setTab} />
      <button onClick={() => setReport(true)} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "var(--card)", border: "1px solid var(--border)", color: "var(--sub)", borderRadius: 14, padding: "11px", fontSize: 13.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9V2h12v7" /><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><rect x="6" y="14" width="12" height="8" /></svg>
        Aylık rapor / PDF
      </button>
      {report && <Rapor ym={ym} byCat={byCat} totalIncome={totalIncome} totalExpense={totalExpense} net={net} onClose={() => setReport(false)} />}

      {tab === "ay" && (
        <>
          <div style={{ position: "relative", overflow: "hidden", borderRadius: 26, padding: "24px 22px", background: "linear-gradient(150deg, rgba(45,224,192,.16), rgba(139,123,255,.14) 55%, rgba(56,189,248,.10))", border: "1px solid rgba(var(--fg),.12)", boxShadow: "0 24px 50px -24px rgba(45,224,192,.45), inset 0 1px 0 rgba(var(--fg),.18)" }}>
            <div style={{ position: "absolute", top: "-40%", right: "-10%", width: "60%", height: "120%", background: "radial-gradient(circle, rgba(45,224,192,.30), transparent 65%)", filter: "blur(26px)", animation: "bt-pulse 5s ease-in-out infinite", pointerEvents: "none" }} />
            <div style={{ position: "relative" }}>
              <div style={{ fontSize: 12.5, color: "var(--sub)", fontWeight: 600 }}>Net bakiye · gelir − gider</div>
              <div className="num" style={{ fontSize: 42, fontWeight: 700, letterSpacing: "-.025em", fontVariantNumeric: "tabular-nums", marginTop: 6, color: "var(--text)" }}><CountUp value={net} /></div>
              <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                {[["Gelir", totalIncome, "#4ADE80"], ["Gider", totalExpense, "#FB7185"]].map(([l, v, dot]) => (
                  <div key={l} style={{ flex: 1, background: "rgba(var(--fg),.07)", border: "1px solid rgba(var(--fg),.08)", borderRadius: 16, padding: "12px 14px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ width: 7, height: 7, borderRadius: 99, background: dot, boxShadow: `0 0 8px ${dot}` }} />
                      <span style={{ fontSize: 11.5, color: "var(--sub)", fontWeight: 600 }}>{l}</span>
                    </div>
                    <div className="num" style={{ fontSize: 18, fontWeight: 700, color: "var(--text)", fontVariantNumeric: "tabular-nums", marginTop: 4 }}><CountUp value={v} /></div>
                  </div>
                ))}
              </div>
              {totalBudget > 0 && (
                <div style={{ marginTop: 18 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                    <span style={{ fontSize: 12, color: "var(--sub)", fontWeight: 600 }}>Bütçe kullanımı</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: "var(--text)" }}>{budgetMsg}</span>
                  </div>
                  <div style={{ height: 8, borderRadius: 999, background: "rgba(var(--fg),.12)", overflow: "hidden" }}>
                    <div style={{ width: `${pct}%`, height: "100%", borderRadius: 999, background: over ? "#FB7185" : "linear-gradient(90deg,#2DE0C0,#8B7BFF)" }} />
                  </div>
                </div>
              )}
            </div>
          </div>

          <div style={cardBox({ padding: "16px 18px", display: "flex", alignItems: "center", gap: 16 })}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
              <div style={{ fontSize: 30, fontWeight: 800, color: healthColor, lineHeight: 1 }}>{health}</div>
              <div style={{ fontSize: 10, color: "var(--muted)", fontWeight: 600 }}>/ 100</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 700 }}>Bütçe sağlığı</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: healthColor, background: healthColor + "1f", borderRadius: 999, padding: "2px 8px" }}>{healthLabel}</span>
              </div>
              <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 4 }}>{healthNote}</div>
              <div style={{ height: 6, borderRadius: 999, background: "var(--line)", overflow: "hidden", marginTop: 8 }}>
                <div style={{ width: `${health}%`, height: "100%", background: healthColor, transition: "width .3s" }} />
              </div>
            </div>
          </div>

          {(projected != null || dailyLeft != null) && totalExpense > 0 && (
            <div style={{ display: "flex", gap: 12 }}>
              {projected != null && (
                <div style={cardBox({ flex: 1, padding: 15 })}>
                  <div style={{ fontSize: 11.5, color: "var(--muted)", fontWeight: 600 }}>Ay sonu tahmini</div>
                  <div style={{ fontSize: 19, fontWeight: 800, marginTop: 3, fontVariantNumeric: "tabular-nums", color: totalBudget && projected > totalBudget ? "#E11D48" : "var(--text)" }}>{fmt(projected)}</div>
                </div>
              )}
              {dailyLeft != null && (
                <div style={cardBox({ flex: 1, padding: 15 })}>
                  <div style={{ fontSize: 11.5, color: "var(--muted)", fontWeight: 600 }}>Günlük kalan</div>
                  <div style={{ fontSize: 19, fontWeight: 800, marginTop: 3, fontVariantNumeric: "tabular-nums", color: dailyLeft < 0 ? "#E11D48" : "var(--text)" }}>{fmt(dailyLeft)}</div>
                </div>
              )}
            </div>
          )}

          {overCats.length > 0 && (
            <div style={cardBox({ padding: "14px 16px", borderLeft: "3px solid #E11D48" })}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "#E11D48", marginBottom: 6 }}>⚠ Limit aşıldı</div>
              {overCats.map((c) => <div key={c.key} style={{ fontSize: 12.5, color: "var(--sub)", marginTop: 2 }}>{c.label} kategorisi bütçeyi aştı</div>)}
            </div>
          )}

          {payTotal > 0 && (
            <div style={cardBox({ padding: "15px 16px" })}>
              <div style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 10 }}>Ödeme dağılımı</div>
              {[["Kart", pay.kart, "#0D9488"], ["Nakit", pay.nakit, "#F59E0B"]].map(([l, v, col]) => (
                <div key={l} style={{ marginBottom: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}>
                    <span style={{ color: "var(--sub)", fontWeight: 600 }}>{l}</span>
                    <span style={{ fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{fmt(v)} · %{Math.round((v / payTotal) * 100)}</span>
                  </div>
                  <div style={{ height: 6, borderRadius: 999, background: "var(--line)", overflow: "hidden" }}>
                    <div style={{ width: `${(v / payTotal) * 100}%`, height: "100%", background: col }} />
                  </div>
                </div>
              ))}
            </div>
          )}

          {byCat.length > 0 ? (
            <div style={cardBox()}>
              <div style={{ fontSize: 14.5, fontWeight: 700 }}>Gider dağılımı</div>
              <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 14 }}>
                <div style={{ position: "relative", width: 148, height: 148, flexShrink: 0 }}>
                  <div style={{ position: "absolute", inset: 0, borderRadius: 999, background: donutBg }} />
                  <div style={{ position: "absolute", inset: 25, borderRadius: 999, background: "var(--card-solid)" }} />
                  <div style={{ position: "absolute", inset: 25, borderRadius: 999, background: "var(--card)" }} />
                  <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}>
                    <div style={{ fontSize: 10.5, color: "var(--muted)", fontWeight: 600 }}>Toplam gider</div>
                    <div style={{ fontSize: 15, fontWeight: 700, fontVariantNumeric: "tabular-nums", marginTop: 1 }}>{fmt(totalExpense)}</div>
                  </div>
                </div>
                <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 4 }}>
                  {byCat.slice(0, 6).map((c) => (
                    <div key={c.key} onClick={() => onDrill(c.key)} style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer", padding: "5px 6px", margin: "0 -6px", borderRadius: 9 }}>
                      <span style={{ width: 9, height: 9, borderRadius: 3, background: c.color, flexShrink: 0 }} />
                      <span style={{ fontSize: 12.5, color: "var(--sub)", flex: 1, fontWeight: 500 }}>{c.label}</span>
                      <span style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>{fmt(c.value)}</span>
                      <span style={{ color: "var(--muted)", fontSize: 14 }}>›</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : <Empty text="Bu ay için gider yok. Alttaki ＋ ile ekle." />}

          {monthTx.length > 0 && (
            <div style={cardBox()}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 14.5, fontWeight: 700 }}>Son işlemler</span>
                <button onClick={goAll} style={{ background: "transparent", border: "none", color: PRIMARY, fontSize: 12.5, fontWeight: 700, cursor: "pointer", padding: 0, fontFamily: "inherit" }}>Tümü ›</button>
              </div>
              {[...monthTx].sort((a, b) => (b.date < a.date ? -1 : b.date > a.date ? 1 : b.id - a.id)).slice(0, 4).map((t, i) => <TxRow key={t.id} t={t} first={i === 0} catOf={catOf} onEdit={onEdit} />)}
            </div>
          )}
        </>
      )}

      {tab === "trend" && <TrendView tx={tx} ym={ym} />}
      {tab === "hedef" && <Hedefler goals={goals} onAdd={onAddGoal} onContribute={onContribute} onDel={onDelGoal} />}
      {tab === "kart" && <Kartlar cards={cards} cardTxns={cardTxns} cardPaid={cardPaid} ym={ym} onAddCard={onAddCard} onAddCardTxn={onAddCardTxn} onDelCardTxn={onDelCardTxn} onPayStatement={onPayStatement} onDelCard={onDelCard} />}
    </div>
  );
}

function TrendView({ tx, ym }) {
  const [metric, setMetric] = useState("expense");
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const dt = new Date(ym.y, ym.m - i, 1);
    const k = ymKey(dt.getFullYear(), dt.getMonth());
    const mtx = tx.filter((t) => (t.date || "").startsWith(k));
    const exp = mtx.filter((t) => t.type === "expense").reduce((a, t) => a + t.amount, 0);
    const inc = mtx.filter((t) => t.type === "income").reduce((a, t) => a + t.amount, 0);
    const val = metric === "expense" ? exp : metric === "income" ? inc : inc - exp;
    months.push({ label: MONTHS_SHORT[dt.getMonth()], val, current: i === 0 });
  }
  const max = Math.max(...months.map((m) => Math.abs(m.val)), 1);
  const thisM = months[5].val, prevM = months[4].val;
  const delta = prevM !== 0 ? Math.round(((thisM - prevM) / Math.abs(prevM)) * 100) : null;
  const avg = months.reduce((a, m) => a + m.val, 0) / 6;
  const barColor = (m) => metric === "net" ? (m.val < 0 ? "#E11D48" : "#16A34A") : metric === "income" ? "#16A34A" : "linear-gradient(180deg,#14B8A6,#0D9488)";

  return (
    <>
      <Seg sm options={[["expense", "Gider"], ["income", "Gelir"], ["net", "Net"]]} value={metric} onChange={setMetric} />
      <div style={cardBox()}>
        <div style={{ fontSize: 14.5, fontWeight: 700 }}>Son 6 ay</div>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 8, height: 150, marginTop: 16 }}>
          {months.map((m, i) => (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 7, height: "100%", justifyContent: "flex-end" }}>
              <div style={{ fontSize: 10, color: "var(--muted)", fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>{m.val !== 0 ? fmtShort(m.val) : ""}</div>
              <div style={{ width: "100%", maxWidth: 34, height: `${Math.max(4, (Math.abs(m.val) / max) * 110)}px`, borderRadius: 8, background: m.current ? barColor(m) : "var(--chip)", opacity: m.current ? 1 : 0.85, transition: "height .3s" }} />
              <div style={{ fontSize: 11, color: m.current ? PRIMARY : "var(--sub)", fontWeight: m.current ? 700 : 500 }}>{m.label}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", gap: 12 }}>
        <div style={cardBox({ flex: 1, padding: 16 })}>
          <div style={{ fontSize: 12, color: "var(--muted)", fontWeight: 600 }}>Geçen aya göre</div>
          <div style={{ fontSize: 22, fontWeight: 800, marginTop: 4, color: delta == null ? "var(--text)" : delta > 0 ? (metric === "expense" ? "#E11D48" : "#16A34A") : (metric === "expense" ? "#16A34A" : "#E11D48") }}>{delta == null ? "—" : `${delta > 0 ? "▲" : "▼"} %${Math.abs(delta)}`}</div>
        </div>
        <div style={cardBox({ flex: 1, padding: 16 })}>
          <div style={{ fontSize: 12, color: "var(--muted)", fontWeight: 600 }}>6 ay ortalaması</div>
          <div style={{ fontSize: 22, fontWeight: 800, marginTop: 4, fontVariantNumeric: "tabular-nums" }}>{fmt(Math.round(avg))}</div>
        </div>
      </div>
    </>
  );
}

function Hedefler({ goals, onAdd, onContribute, onDel }) {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [target, setTarget] = useState("");
  const [color, setColor] = useState(CAT_PALETTE[0]);
  const add = () => { const t = parseAmount(target); if (!name.trim() || !t || t <= 0) return; onAdd(name.trim(), t, color); setName(""); setTarget(""); setAdding(false); };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
      {goals.length === 0 && !adding && <Empty text="Henüz hedef yok. Bir tasarruf hedefi ekle." />}
      {goals.map((g) => {
        const p = Math.min(100, (g.saved / g.target) * 100);
        const done = g.saved >= g.target;
        return (
          <div key={g.id} style={cardBox()}>
            <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
              <span style={{ width: 11, height: 11, borderRadius: 4, background: g.color, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>{g.name}{done && " 🎉"}</div>
                <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2, fontVariantNumeric: "tabular-nums" }}>{fmt(g.saved)} / {fmt(g.target)}</div>
              </div>
              <button onClick={() => onDel(g.id)} style={{ background: "transparent", border: "none", color: "var(--muted)", fontSize: 18, cursor: "pointer", fontFamily: "inherit" }}>×</button>
            </div>
            <div style={{ height: 8, borderRadius: 999, background: "var(--line)", overflow: "hidden", marginTop: 12 }}>
              <div style={{ width: `${p}%`, height: "100%", borderRadius: 999, background: g.color, transition: "width .3s" }} />
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              {[500, 1000, 5000].map((v) => <button key={v} onClick={() => onContribute(g.id, v)} style={{ flex: 1, background: "var(--chip)", color: "var(--text)", border: "none", borderRadius: 11, padding: "9px 0", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>+{fmtShort(v)}</button>)}
              <button onClick={() => onContribute(g.id, -1000)} style={{ background: "var(--chip)", color: "var(--muted)", border: "none", borderRadius: 11, padding: "9px 12px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>−1k</button>
            </div>
          </div>
        );
      })}

      {adding ? (
        <div style={cardBox({ display: "flex", flexDirection: "column", gap: 12 })}>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Hedef adı (örn. Tatil)" style={fieldStyle} autoFocus />
          <input type="text" inputMode="decimal" value={target} onChange={(e) => setTarget(e.target.value)} placeholder="Hedef tutar ₺" style={fieldStyle} />
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {CAT_PALETTE.map((col) => <button key={col} onClick={() => setColor(col)} style={{ width: 30, height: 30, borderRadius: 9, background: col, border: color === col ? "3px solid var(--text)" : "3px solid transparent", cursor: "pointer" }} />)}
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={add} style={{ flex: 1, background: PRIMARY, color: "#fff", border: "none", borderRadius: 14, padding: 14, fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Ekle</button>
            <button onClick={() => setAdding(false)} style={{ background: "var(--chip)", color: "var(--sub)", border: "none", borderRadius: 14, padding: "14px 20px", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>İptal</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setAdding(true)} style={{ background: "var(--card)", color: PRIMARY, border: "1.5px dashed var(--addDash)", borderRadius: 16, padding: 15, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>＋ Tasarruf hedefi ekle</button>
      )}
    </div>
  );
}

function Kartlar({ cards, cardTxns, cardPaid, ym, onAddCard, onAddCardTxn, onDelCardTxn, onPayStatement, onDelCard }) {
  const [adding, setAdding] = useState(false);
  const [open, setOpen] = useState(null);
  const [name, setName] = useState("");
  const [limit, setLimit] = useState("");
  const [sDay, setSDay] = useState("1");
  const [dDay, setDDay] = useState("10");
  const [accent, setAccent] = useState("mor");
  const curYm = ymKey(ym.y, ym.m);
  const paidSet = new Set(cardPaid.map((p) => p.cardId + "|" + p.ym));
  const totalDebt = cards.reduce((s, c) => s + cardSummary(c, cardTxns, paidSet, curYm).debt, 0);
  const totalLimit = cards.reduce((s, c) => s + (c.limit || 0), 0);

  const add = () => {
    const lim = parseAmount(limit);
    if (!name.trim() || !lim || lim <= 0) return;
    onAddCard({ name: name.trim(), limit: lim, statementDay: Math.min(28, Math.max(1, parseInt(sDay, 10) || 1)), dueDay: Math.min(28, Math.max(1, parseInt(dDay, 10) || 10)), accent, last4: String(Math.floor(1000 + Math.random() * 9000)) });
    setName(""); setLimit(""); setSDay("1"); setDDay("10"); setAccent("mor"); setAdding(false);
  };
  const openCard = open ? cards.find((c) => c.id === open) : null;
  const lbl = { fontSize: 11, fontWeight: 700, color: "#8089a3", letterSpacing: ".05em", textTransform: "uppercase" };

  return (
    <div style={{ ...CARD_SHELL, padding: "20px 16px 22px" }}>
      <div style={{ position: "absolute", top: -70, left: -50, width: 240, height: 240, borderRadius: "50%", background: "#5b3bd4", filter: "blur(120px)", opacity: 0.32, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "42%", right: -80, width: 220, height: 220, borderRadius: "50%", background: "#0e7c86", filter: "blur(120px)", opacity: 0.26, pointerEvents: "none" }} />

      <div style={{ position: "relative", zIndex: 2, display: "flex", flexDirection: "column", gap: 16 }}>
        {cards.length > 0 && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 4px" }}>
            <div>
              <div style={lbl}>Toplam borç</div>
              <div style={{ fontSize: 25, fontWeight: 800, color: "#f2f4f9", letterSpacing: "-.02em", marginTop: 3, fontVariantNumeric: "tabular-nums" }}>{fmt(totalDebt)}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={lbl}>Toplam limit</div>
              <div style={{ fontSize: 17, fontWeight: 700, color: "#aeb6c9", marginTop: 5, fontVariantNumeric: "tabular-nums" }}>{fmt(totalLimit)}</div>
            </div>
          </div>
        )}

        {cards.length === 0 && !adding && <div style={{ textAlign: "center", color: "#8089a3", fontSize: 13.5, padding: "32px 20px", border: "1px dashed rgba(255,255,255,0.14)", borderRadius: 18 }}>Henüz kart yok. Bir kredi kartı ekle.</div>}

        {cards.map((c) => {
          const s = cardSummary(c, cardTxns, paidSet, curYm);
          const usage = c.limit ? Math.min(100, (s.debt / c.limit) * 100) : 0;
          const paid = paidSet.has(c.id + "|" + curYm);
          const sk = cardSkin(c.accent);
          const badge = paid ? { bg: "rgba(22,184,166,.18)", bd: "rgba(22,184,166,.4)", fg: "#5ee7d3", t: "✓ Ekstre ödendi" } : { bg: "rgba(240,179,77,.18)", bd: "rgba(240,179,77,.4)", fg: "#f0b34d", t: "Ödeme bekliyor" };
          return (
            <div key={c.id} className="bt-row" style={{ ...sk.wrap, cursor: "pointer", animation: "bt-rise .45s ease both" }} onClick={() => setOpen(c.id)}>
              <div style={sk.glow} /><div style={sk.sheen} />
              <div style={{ position: "relative", zIndex: 2 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={sk.chipWrap}><div style={sk.chipInner} /></div>
                    <div>
                      <div style={{ fontSize: 17, fontWeight: 800, letterSpacing: "-.01em" }}>{c.name}</div>
                      <div style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,.55)", letterSpacing: ".08em", marginTop: 2 }}>•••• {c.last4 || "••••"}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 700, padding: "6px 11px", borderRadius: 99, whiteSpace: "nowrap", background: badge.bg, border: `1px solid ${badge.bd}`, color: badge.fg }}>{badge.t}</div>
                </div>
                <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,.6)", letterSpacing: ".08em", textTransform: "uppercase" }}>Güncel borç</div>
                <div style={{ fontSize: 37, fontWeight: 800, letterSpacing: "-.03em", marginTop: 2, lineHeight: 1.05, fontVariantNumeric: "tabular-nums" }}>{fmt(s.debt)}</div>
                <div style={{ height: 8, borderRadius: 99, background: "rgba(0,0,0,.22)", overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)", marginTop: 20 }}>
                  <div style={{ width: `${Math.max(usage, usage > 0 ? 4 : 0)}%`, height: "100%", borderRadius: 99, background: `linear-gradient(90deg,#ffffff,${sk.a.glow})`, boxShadow: `0 0 12px ${sk.a.glow}`, transition: "width .8s cubic-bezier(.2,.7,.2,1)" }} />
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 11, fontSize: 13, color: "rgba(255,255,255,.7)", fontWeight: 600 }}>
                  <span>Kullanılabilir <b style={{ color: "#fff", fontWeight: 800 }}>{fmt(s.available)}</b></span>
                  <span style={{ fontSize: 12, fontWeight: 700, padding: "3px 9px", borderRadius: 8, background: "rgba(255,255,255,.12)", color: "#fff" }}>%{Math.round(usage)} kullanım</span>
                </div>
              </div>
            </div>
          );
        })}

        {adding ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 12, padding: 16, borderRadius: 18, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Kart adı (örn. Maximum)" style={glassInput} autoFocus />
            <input type="text" inputMode="decimal" value={limit} onChange={(e) => setLimit(e.target.value)} placeholder="Kart limiti ₺" style={glassInput} />
            <div style={{ display: "flex", gap: 10 }}>
              <div style={{ flex: 1 }}><label style={lbl}>Kesim günü</label><input type="number" value={sDay} onChange={(e) => setSDay(e.target.value)} style={{ ...glassInput, marginTop: 5, textAlign: "center" }} /></div>
              <div style={{ flex: 1 }}><label style={lbl}>Son ödeme</label><input type="number" value={dDay} onChange={(e) => setDDay(e.target.value)} style={{ ...glassInput, marginTop: 5, textAlign: "center" }} /></div>
            </div>
            <div>
              <label style={lbl}>Kart rengi</label>
              <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
                {ACCENT_KEYS.map((k) => { const a = ACCENTS[k]; const on = accent === k; return <button key={k} onClick={() => setAccent(k)} style={{ flex: 1, height: 46, borderRadius: 13, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", background: `linear-gradient(140deg, ${a.glow}, ${a.solid})`, border: on ? "2px solid #fff" : "2px solid rgba(255,255,255,0.12)", boxShadow: `0 4px 14px ${a.glow}${on ? "88" : "33"}` }}>{on && <span style={{ color: "#fff", fontSize: 17, fontWeight: 800 }}>✓</span>}</button>; })}
              </div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={add} style={{ flex: 1, background: "linear-gradient(135deg,#16b8a6,#0e8f86)", color: "#fff", border: "none", borderRadius: 14, padding: 14, fontWeight: 800, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Ekle</button>
              <button onClick={() => setAdding(false)} style={{ background: "rgba(255,255,255,0.06)", color: "#aeb6c9", border: "none", borderRadius: 14, padding: "14px 20px", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>İptal</button>
            </div>
          </div>
        ) : (
          <button onClick={() => setAdding(true)} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 9, width: "100%", padding: 18, borderRadius: 20, border: "1.5px dashed rgba(255,255,255,0.18)", background: "rgba(255,255,255,0.03)", color: "#aeb6c9", fontFamily: "inherit", fontSize: 15, fontWeight: 700, cursor: "pointer" }}><span style={{ fontSize: 20, lineHeight: 0 }}>+</span> Kart ekle</button>
        )}
      </div>

      {openCard && <CardDetail card={openCard} cardTxns={cardTxns} paidSet={paidSet} ym={ym} onClose={() => setOpen(null)} onAddTxn={onAddCardTxn} onDelTxn={onDelCardTxn} onPay={onPayStatement} onDelCard={onDelCard} />}
    </div>
  );
}

function CardDetail({ card, cardTxns, paidSet, ym, onClose, onAddTxn, onDelTxn, onPay, onDelCard }) {
  const [adding, setAdding] = useState(false);
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");
  const [inst, setInst] = useState("1");
  const [date, setDate] = useState(todayISO());
  const curYm = ymKey(ym.y, ym.m);
  const s = cardSummary(card, cardTxns, paidSet, curYm);
  const usage = card.limit ? Math.min(100, (s.debt / card.limit) * 100) : 0;
  const paid = paidSet.has(card.id + "|" + curYm);
  const sk = cardSkin(card.accent, 26);
  const mine = cardTxns.filter((t) => t.cardId === card.id).sort((a, b) => (b.date < a.date ? -1 : 1));
  const lbl = { fontSize: 11, fontWeight: 700, color: "#8089a3", letterSpacing: ".04em", textTransform: "uppercase" };
  const glass = (extra) => ({ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", ...extra });

  const add = () => {
    const a = parseAmount(amount); const n = Math.max(1, parseInt(inst, 10) || 1);
    if (!a || a <= 0) return;
    onAddTxn({ cardId: card.id, amount: a, installments: n, description: desc.trim(), date });
    setAmount(""); setDesc(""); setInst("1"); setDate(todayISO()); setAdding(false);
  };

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 60, background: "rgba(0,0,0,.6)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ ...CARD_SHELL, width: "100%", maxWidth: 440, borderRadius: "24px 24px 0 0", padding: "10px 18px 26px", maxHeight: "92vh", overflowY: "auto", animation: "bt-sheet .28s cubic-bezier(.2,.8,.2,1) both" }}>
        <div style={{ width: 40, height: 4, borderRadius: 999, background: "rgba(255,255,255,0.18)", margin: "4px auto 14px" }} />
        <div style={{ position: "relative", zIndex: 2, display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ ...sk.wrap, height: 190, padding: 22 }}>
            <div style={sk.glow} /><div style={sk.sheen} />
            <div style={{ position: "relative", zIndex: 2, display: "flex", flexDirection: "column", height: "100%", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                <div style={sk.chipWrap}><div style={sk.chipInner} /></div>
                <div style={{ fontSize: 16, fontWeight: 800, color: "rgba(255,255,255,.9)", fontStyle: "italic" }}>{card.name}</div>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: "rgba(255,255,255,.6)", letterSpacing: ".08em", textTransform: "uppercase" }}>Güncel borç</div>
                <div style={{ fontSize: 33, fontWeight: 800, letterSpacing: "-.02em", lineHeight: 1.1, fontVariantNumeric: "tabular-nums" }}>{fmt(s.debt)}</div>
              </div>
              <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
                <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: ".12em" }}>•••• {card.last4 || "••••"}</div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 9, fontWeight: 600, color: "rgba(255,255,255,.5)", letterSpacing: ".06em" }}>SON ÖDEME</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,.9)" }}>{card.dueDay} {MONTHS_SHORT[ym.m]}</div>
                </div>
              </div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {[
              { k: "Toplam limit", val: fmt(card.limit), c: "#f2f4f9" },
              { k: "Kullanılabilir", val: fmt(s.available), c: "#5ee7d3" },
              { k: "Kullanım", val: "%" + Math.round(usage), c: "#f2f4f9" },
              { k: "Bu ay ekstre", val: fmt(s.statement), c: paid ? "#5ee7d3" : "#f2f4f9" },
            ].map((x) => (
              <div key={x.k} style={glass({ padding: 14, borderRadius: 16 })}>
                <div style={lbl}>{x.k}</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: x.c, marginTop: 5, fontVariantNumeric: "tabular-nums" }}>{x.val}</div>
              </div>
            ))}
          </div>

          <button onClick={() => onPay(card.id, curYm)} style={{ background: paid ? "rgba(255,255,255,0.06)" : "linear-gradient(135deg,#16b8a6,#0e8f86)", color: paid ? "#aeb6c9" : "#fff", border: "none", borderRadius: 16, padding: 15, fontSize: 15, fontWeight: 800, cursor: "pointer", fontFamily: "inherit", boxShadow: paid ? "none" : "0 10px 24px -8px rgba(14,143,134,.5)" }}>{paid ? `${MONTHS_SHORT[ym.m]} ekstresi ödendi ✓ (geri al)` : `Ekstreyi öde · ${fmt(s.statement)}`}</button>

          <div style={{ fontSize: 14, fontWeight: 800, color: "#f2f4f9", padding: "4px 4px 0" }}>İşlemler ve taksitler</div>
          {mine.length === 0 ? <div style={{ textAlign: "center", color: "#8089a3", fontSize: 13.5, padding: 24, ...glass({ borderRadius: 16 }) }}>Bu kartta işlem yok.</div> : (
            <div style={glass({ borderRadius: 18, overflow: "hidden" })}>
              {mine.map((t, i) => {
                const ports = cardTxnPortions(t, card);
                const remaining = ports.filter((p) => p.ym >= curYm && !paidSet.has(card.id + "|" + p.ym)).length;
                const n = Math.max(1, t.installments || 1);
                return (
                  <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 14px", borderBottom: i < mine.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                    <div style={{ width: 40, height: 40, borderRadius: 12, background: "rgba(255,255,255,0.07)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, flexShrink: 0 }}>{(t.description || "Kart").slice(0, 2)}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14.5, fontWeight: 700, color: "#eef1f7" }}>{t.description || "Harcama"}</div>
                      <div style={{ fontSize: 12, color: "#8089a3", marginTop: 1 }}>{new Date(t.date).toLocaleDateString("tr-TR", { day: "numeric", month: "short" })}{n > 1 ? ` · ${n} taksit · kalan ${remaining}` : " · tek çekim"}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 14.5, fontWeight: 800, color: "#eef1f7", fontVariantNumeric: "tabular-nums" }}>{fmt(t.amount)}</div>
                      {n > 1 && <div style={{ fontSize: 11, color: "#8089a3" }}>{fmt(cardMonthly(t))}/ay</div>}
                    </div>
                    <button onClick={() => onDelTxn(t.id)} style={{ background: "transparent", border: "none", color: "#8089a3", fontSize: 18, cursor: "pointer", fontFamily: "inherit" }}>×</button>
                  </div>
                );
              })}
            </div>
          )}

          {adding ? (
            <div style={glass({ display: "flex", flexDirection: "column", gap: 11, padding: 16, borderRadius: 16 })}>
              <input type="text" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Tutar ₺" style={glassInput} autoFocus />
              <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Açıklama (örn. Telefon)" style={glassInput} />
              <div>
                <label style={lbl}>Taksit</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginTop: 7 }}>
                  {[1, 2, 3, 6, 9, 12].map((n) => <button key={n} onClick={() => setInst(String(n))} style={{ background: inst === String(n) ? "linear-gradient(135deg,#16b8a6,#0e8f86)" : "rgba(255,255,255,0.06)", color: inst === String(n) ? "#fff" : "#aeb6c9", border: "none", borderRadius: 999, padding: "8px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>{n === 1 ? "Tek" : n}</button>)}
                </div>
              </div>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={glassInput} />
              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={add} style={{ flex: 1, background: "linear-gradient(135deg,#16b8a6,#0e8f86)", color: "#fff", border: "none", borderRadius: 14, padding: 13, fontWeight: 800, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Ekle</button>
                <button onClick={() => setAdding(false)} style={{ background: "rgba(255,255,255,0.06)", color: "#aeb6c9", border: "none", borderRadius: 14, padding: "13px 18px", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>İptal</button>
              </div>
            </div>
          ) : (
            <button onClick={() => setAdding(true)} style={{ background: "rgba(255,255,255,0.03)", color: "#aeb6c9", border: "1.5px dashed rgba(255,255,255,0.18)", borderRadius: 14, padding: 13, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>＋ Kart harcaması ekle</button>
          )}

          <button onClick={() => { onClose(); onDelCard(card.id); }} style={{ background: "transparent", color: "#ff8095", border: "none", padding: 8, fontWeight: 600, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" }}>Kartı sil</button>
        </div>
      </div>
    </div>
  );
}

function CatIcon({ k, size = 21 }) {
  const sw = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
  const key = (k || "").startsWith("custom_") ? "diger" : k;
  const icons = {
    market: <><circle cx="9" cy="20" r="1.4" /><circle cx="18" cy="20" r="1.4" /><path d="M2 3h2.2l2.3 12.2a1.6 1.6 0 0 0 1.6 1.3h8.7a1.6 1.6 0 0 0 1.6-1.3L20 7H5.2" /></>,
    yeme: <><path d="M5 2v6a2 2 0 0 0 4 0V2" /><path d="M7 8v14" /><path d="M16 2c2.2 0 3.3 2 3.3 5s-1.1 5-3.3 5" /><path d="M16 2v20" /></>,
    ulasim: <><rect x="4" y="4" width="16" height="11" rx="2.5" /><path d="M4 10h16" /><circle cx="8" cy="18" r="1.5" /><circle cx="16" cy="18" r="1.5" /><path d="M8 15v1.5M16 15v1.5" /></>,
    fatura: <><path d="M14 3H7a2 2 0 0 0-2 2v15l2.5-1.5L10 20l2-1.5L14 20l2.5-1.5L19 20V8z" /><path d="M14 3v5h5" /><path d="M9 12h6M9 16h4" /></>,
    eglence: <><circle cx="12" cy="12" r="9" /><path d="M10 8.5l5.5 3.5L10 15.5z" fill="currentColor" stroke="none" /></>,
    saglik: <path d="M19 5.6a4.4 4.4 0 0 0-7 1 4.4 4.4 0 0 0-7-1 4.7 4.7 0 0 0 0 6.7L12 20l7-7.7a4.7 4.7 0 0 0 0-6.7z" />,
    maas: <><rect x="2.5" y="6" width="19" height="13" rx="2.5" /><path d="M2.5 10.5h19" /><circle cx="17" cy="14.5" r="1.4" fill="currentColor" stroke="none" /></>,
    ek: <><path d="M3 17l6-6 4 4 8-8" /><path d="M16 7h5v5" /></>,
    gelir_diger: <><ellipse cx="12" cy="6.5" rx="7" ry="3" /><path d="M5 6.5v6c0 1.6 3.1 3 7 3s7-1.4 7-3v-6" /><path d="M5 12.5v5c0 1.6 3.1 3 7 3s7-1.4 7-3v-5" /></>,
    diger: <><circle cx="5" cy="12" r="1.6" fill="currentColor" stroke="none" /><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" /><circle cx="19" cy="12" r="1.6" fill="currentColor" stroke="none" /></>,
  };
  return <svg {...sw}>{icons[key] || icons.diger}</svg>;
}

function CountUp({ value, className, style }) {
  const [disp, setDisp] = useState(value);
  const prev = useRef(value);
  useEffect(() => {
    const from = prev.current, to = value; prev.current = value;
    if (from === to) { setDisp(to); return; }
    let reduce = false; try { reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches; } catch {}
    if (reduce) { setDisp(to); return; }
    let raf; const t0 = performance.now(), dur = 600;
    const tick = (t) => { const k = Math.min(1, (t - t0) / dur); const e = 1 - Math.pow(1 - k, 3); setDisp(from + (to - from) * e); if (k < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  const shown = disp === value ? value : Math.round(disp);
  return <span className={className} style={style}>{fmt(shown)}</span>;
}

function TxRow({ t, first, catOf, onEdit, onDel, swipe }) {
  const c = catOf(t.category);
  const isInc = t.type === "income";
  const canSwipe = !!(swipe && onDel);
  const [dx, setDx] = useState(0);
  const d = useRef(null); const moved = useRef(false);
  const down = (e) => { if (!canSwipe) return; d.current = { x: e.clientX }; moved.current = false; try { e.currentTarget.setPointerCapture(e.pointerId); } catch {} };
  const moveH = (e) => { if (!d.current) return; const off = e.clientX - d.current.x; if (Math.abs(off) > 6) moved.current = true; setDx(Math.max(-96, Math.min(0, off))); };
  const up = () => { if (!d.current) return; const del = dx < -60; d.current = null; if (del) { setDx(-400); setTimeout(() => onDel(t.id), 160); } else setDx(0); };
  const content = (<>
      <div style={{ width: 40, height: 40, borderRadius: 12, background: c.color + "22", color: c.color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><CatIcon k={t.category} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.description || c.label}</div>
        <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>{c.label}{!isInc && t.method === "nakit" ? " · Nakit" : ""} · {new Date(t.date).toLocaleDateString("tr-TR", { day: "numeric", month: "short" })}{t.recurringId ? " · ↻" : ""}</div>
      </div>
      <div style={{ fontSize: 15, fontWeight: 700, fontVariantNumeric: "tabular-nums", color: isInc ? "#16A34A" : "var(--text)" }}>{isInc ? "+" : "−"}{fmt(t.amount)}</div>
      {onDel && !canSwipe && <button onClick={(e) => { e.stopPropagation(); onDel(t.id); }} style={{ background: "transparent", border: "none", color: "var(--muted)", fontSize: 21, lineHeight: 1, cursor: "pointer", padding: "0 2px", marginLeft: 2, fontFamily: "inherit" }}>×</button>}
  </>);
  if (!canSwipe) {
    return <div onClick={() => onEdit && onEdit(t)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 0", borderTop: first ? "none" : "1px solid var(--line)", cursor: onEdit ? "pointer" : "default" }}>{content}</div>;
  }
  return (
    <div style={{ position: "relative", borderTop: first ? "none" : "1px solid var(--line)", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, background: "#E11D48", display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 20, color: "#fff" }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
      </div>
      <div onClick={() => { if (moved.current) { moved.current = false; return; } onEdit && onEdit(t); }} onPointerDown={down} onPointerMove={moveH} onPointerUp={up} onPointerCancel={() => { d.current = null; setDx(0); }} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 12px", cursor: "pointer", background: "var(--bg)", transform: `translateX(${dx}px)`, transition: d.current ? "none" : "transform .2s ease", touchAction: "pan-y", position: "relative", zIndex: 1 }}>{content}</div>
    </div>
  );
}

// ---------- İŞLEMLER ----------
function Islemler({ monthTx, allTx, catOf, onEdit, onDel }) {
  const [q, setQ] = useState("");
  const [type, setType] = useState("all");
  const [sort, setSort] = useState("date");
  const [scope, setScope] = useState("month");

  const base = scope === "all" ? allTx : monthTx;
  let list = base.filter((t) => {
    if (type !== "all" && t.type !== type) return false;
    if (q.trim()) { const s = ((t.description || "") + " " + catOf(t.category).label).toLowerCase(); if (!s.includes(q.trim().toLowerCase())) return false; }
    return true;
  });
  list = [...list].sort((a, b) => sort === "amount" ? b.amount - a.amount : (b.date < a.date ? -1 : b.date > a.date ? 1 : b.id - a.id));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍  İşlem ara…" style={fieldStyle} />
      <div style={{ display: "flex", gap: 10 }}>
        <div style={{ flex: 1 }}><Seg sm options={[["all", "Tümü"], ["expense", "Gider"], ["income", "Gelir"]]} value={type} onChange={setType} /></div>
        <button onClick={() => setSort(sort === "date" ? "amount" : "date")} style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 14, padding: "0 14px", fontSize: 12.5, fontWeight: 700, color: "var(--sub)", cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" }}>{sort === "date" ? "Tarih ↓" : "Tutar ↓"}</button>
      </div>
      <Seg sm options={[["month", "Bu ay"], ["all", "Tüm aylar"]]} value={scope} onChange={setScope} />

      {list.length === 0 ? <Empty text="Eşleşen işlem yok." pad={48} /> : (
        <div style={cardBox()}>
          <div style={{ fontSize: 14.5, fontWeight: 700, marginBottom: 4 }}>{list.length} işlem · {fmt(list.reduce((a, t) => a + (t.type === "expense" ? t.amount : 0), 0))} gider</div>
          {list.slice(0, 200).map((t, i) => <TxRow key={t.id} t={t} first={i === 0} catOf={catOf} onEdit={onEdit} onDel={onDel} swipe />)}
        </div>
      )}
    </div>
  );
}

// ---------- EKLE ----------
function Ekle({ expCats, catOf, tx, onAdd, onDone, onOpenAI }) {
  const [type, setType] = useState("expense");
  const [amount, setAmount] = useState("");
  const cats = type === "expense" ? expCats : INC_CATS;
  const [category, setCategory] = useState("market");
  const [desc, setDesc] = useState("");
  const [date, setDate] = useState(todayISO());
  const [method, setMethod] = useState("kart");
  const isInc = type === "income";

  // hızlı şablonlar: son benzersiz gider işlemleri
  const templates = (() => {
    const seen = new Set(); const out = [];
    for (let i = tx.length - 1; i >= 0 && out.length < 4; i--) {
      const t = tx[i]; if (t.type !== "expense") continue;
      const k = (t.description || t.category) + "|" + t.amount;
      if (seen.has(k)) continue; seen.add(k); out.push(t);
    }
    return out;
  })();

  const switchType = (t) => { setType(t); setCategory((t === "expense" ? expCats : INC_CATS)[0].key); };
  const submit = () => { const a = parseAmount(amount); if (!a || a <= 0) return; onAdd({ type, amount: a, category, description: desc.trim(), date, ...(type === "expense" ? { method } : {}) }); onDone(); };
  const quickAdd = (t) => { onAdd({ type: "expense", amount: t.amount, category: t.category, description: t.description, date: todayISO(), method: t.method || "kart" }); onDone(); };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {AI_ENABLED && (
      <button onClick={onOpenAI} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 9, background: "linear-gradient(135deg,#2DE0C0,#38BDF8)", color: "#06121a", border: "none", borderRadius: 16, padding: "14px", fontSize: 14.5, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", boxShadow: "0 12px 24px -10px rgba(14,165,233,.55)" }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3l1.6 4.6L18 9l-4.4 1.4L12 15l-1.6-4.6L6 9l4.4-1.4L12 3z" /><path d="M19 14l.8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8L19 14z" /></svg>
        Yapay zeka ile ekle
      </button>
      )}
      {templates.length > 0 && (
        <div>
          <div style={{ fontSize: 11.5, color: "var(--muted)", fontWeight: 700, letterSpacing: ".04em", marginBottom: 8, padding: "0 2px" }}>HIZLI EKLE</div>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 2 }}>
            {templates.map((t) => {
              const c = catOf(t.category);
              return <button key={t.id} onClick={() => quickAdd(t)} style={{ flexShrink: 0, background: "var(--card)", border: "1px solid var(--border)", borderRadius: 13, padding: "9px 13px", display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontFamily: "inherit", boxShadow: "var(--cardShadowSm)" }}>
                <span style={{ width: 8, height: 8, borderRadius: 3, background: c.color }} />
                <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--text)" }}>{t.description || c.label}</span>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: "var(--sub)", fontVariantNumeric: "tabular-nums" }}>{fmt(t.amount)}</span>
              </button>;
            })}
          </div>
        </div>
      )}

      <div style={{ display: "flex", gap: 6, background: "var(--card)", padding: 5, borderRadius: 16, boxShadow: "var(--cardShadowSm)" }}>
        {[["expense", "Gider", "#E11D48"], ["income", "Gelir", "#16A34A"]].map(([k, l, col]) => <button key={k} onClick={() => switchType(k)} style={{ flex: 1, padding: 11, borderRadius: 11, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 14, fontFamily: "inherit", background: type === k ? col : "transparent", color: type === k ? "#fff" : "var(--muted)" }}>{l}</button>)}
      </div>
      <div style={cardBox()}>
        <label style={{ fontSize: 12.5, color: "var(--sub)", fontWeight: 600 }}>Tutar</label>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginTop: 4 }}>
          <span style={{ fontSize: 30, fontWeight: 600, color: "var(--muted)" }}>₺</span>
          <input type="text" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" autoFocus style={{ flex: 1, minWidth: 0, background: "transparent", border: "none", outline: "none", fontSize: 40, fontWeight: 700, color: "var(--text)", padding: "4px 0" }} />
        </div>
      </div>
      <div style={cardBox()}>
        <label style={{ fontSize: 12.5, color: "var(--sub)", fontWeight: 600 }}>Kategori</label>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 11 }}>{cats.map((c) => <Chip key={c.key} label={c.label} active={category === c.key} color={c.color} onClick={() => setCategory(c.key)} />)}</div>
      </div>
      {!isInc && (
        <div style={cardBox()}>
          <label style={{ fontSize: 12.5, color: "var(--sub)", fontWeight: 600 }}>Ödeme yöntemi</label>
          <div style={{ display: "flex", gap: 8, marginTop: 11 }}>
            {[["kart", "Kart"], ["nakit", "Nakit"]].map(([k, l]) => <button key={k} onClick={() => setMethod(k)} style={{ flex: 1, padding: 11, borderRadius: 12, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 13.5, fontFamily: "inherit", background: method === k ? PRIMARY : "var(--chip)", color: method === k ? "#fff" : "var(--sub)" }}>{l}</button>)}
          </div>
        </div>
      )}
      <div style={cardBox({ display: "flex", flexDirection: "column", gap: 13 })}>
        <div><label style={{ fontSize: 12.5, color: "var(--sub)", fontWeight: 600 }}>Açıklama</label><input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder={isInc ? "örn. Şubat maaşı" : "örn. Market"} style={{ ...fieldStyle, marginTop: 7 }} /></div>
        <div><label style={{ fontSize: 12.5, color: "var(--sub)", fontWeight: 600 }}>Tarih</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={{ ...fieldStyle, marginTop: 7 }} /></div>
      </div>
      <button onClick={submit} style={{ background: isInc ? "#16A34A" : PRIMARY, color: "#fff", border: "none", borderRadius: 16, padding: 16, fontSize: 16, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", boxShadow: `0 12px 24px -10px ${isInc ? "rgba(22,163,74,.5)" : "rgba(13,148,136,.5)"}` }}>Kaydet</button>
    </div>
  );
}

function EditSheet({ tx, expCats, onClose, onSave, onDelete }) {
  const [type, setType] = useState(tx.type);
  const [amount, setAmount] = useState(String(tx.amount));
  const cats = type === "expense" ? expCats : INC_CATS;
  const [category, setCategory] = useState(tx.category);
  const [desc, setDesc] = useState(tx.description || "");
  const [date, setDate] = useState(tx.date);
  const [method, setMethod] = useState(tx.method || "kart");
  const switchType = (t) => { setType(t); setCategory((t === "expense" ? expCats : INC_CATS)[0].key); };
  const save = () => { const a = parseAmount(amount); if (!a || a <= 0) return; onSave({ type, amount: a, category, description: desc.trim(), date, ...(type === "expense" ? { method } : { method: undefined }) }); };
  return (
    <Sheet title="İşlemi düzenle" onClose={onClose}>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", gap: 6, background: "var(--card)", padding: 5, borderRadius: 14, boxShadow: "var(--cardShadowSm)" }}>
          {[["expense", "Gider", "#E11D48"], ["income", "Gelir", "#16A34A"]].map(([k, l, col]) => <button key={k} onClick={() => switchType(k)} style={{ flex: 1, padding: 10, borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 13.5, fontFamily: "inherit", background: type === k ? col : "transparent", color: type === k ? "#fff" : "var(--muted)" }}>{l}</button>)}
        </div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, background: "var(--card)", borderRadius: 16, padding: "12px 16px", boxShadow: "var(--cardShadowSm)" }}>
          <span style={{ fontSize: 24, fontWeight: 600, color: "var(--muted)" }}>₺</span>
          <input type="text" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ flex: 1, minWidth: 0, background: "transparent", border: "none", outline: "none", fontSize: 30, fontWeight: 700, color: "var(--text)" }} />
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{cats.map((c) => <Chip key={c.key} small label={c.label} active={category === c.key} color={c.color} onClick={() => setCategory(c.key)} />)}</div>
        {type === "expense" && (
          <div style={{ display: "flex", gap: 8 }}>
            {[["kart", "Kart"], ["nakit", "Nakit"]].map(([k, l]) => <button key={k} onClick={() => setMethod(k)} style={{ flex: 1, padding: 11, borderRadius: 12, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 13, fontFamily: "inherit", background: method === k ? PRIMARY : "var(--chip)", color: method === k ? "#fff" : "var(--sub)" }}>{l}</button>)}
          </div>
        )}
        <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Açıklama" style={fieldStyle} />
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={fieldStyle} />
        <div style={{ display: "flex", gap: 10, marginTop: 2 }}>
          <button onClick={onDelete} style={{ background: "transparent", color: "#E11D48", border: "1px solid #E11D48", borderRadius: 14, padding: "13px 18px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>Sil</button>
          <button onClick={save} style={{ flex: 1, background: PRIMARY, color: "#fff", border: "none", borderRadius: 14, padding: 13, fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Kaydet</button>
        </div>
      </div>
    </Sheet>
  );
}

function DrillSheet({ cat, list, onClose, onEdit }) {
  const total = list.reduce((a, t) => a + t.amount, 0);
  return (
    <Sheet title={`${cat.label} · ${fmt(total)}`} onClose={onClose}>
      {list.length === 0 ? <Empty text="Bu kategoride işlem yok." /> : (
        <div>{list.map((t, i) => <TxRow key={t.id} t={t} first={i === 0} catOf={() => cat} onEdit={onEdit} />)}</div>
      )}
    </Sheet>
  );
}

function Onboard({ onClose, onFinish }) {
  const [step, setStep] = useState(0);
  const [income, setIncome] = useState("");
  const [lims, setLims] = useState({});
  const budgetCats = BUILTIN_EXP.filter((c) => ["market", "fatura", "yeme", "ulasim", "eglence"].includes(c.key));
  const setLim = (k, v) => setLims((p) => ({ ...p, [k]: v }));
  const finish = () => { const b = {}; budgetCats.forEach((c) => { const n = parseAmount(lims[c.key] || ""); if (n > 0) b[c.key] = n; }); onFinish(parseAmount(income), b); };

  const Logo = () => (
    <div style={{ position: "relative", width: 84, height: 84, borderRadius: 26, background: "linear-gradient(150deg,#ffffff,#eef6f4)", boxShadow: "0 20px 44px -16px rgba(0,0,0,.5), 0 0 40px -8px rgba(45,224,192,.45)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 7, height: 38 }}>
        {[[24, "#34e3c4,#14b8a6"], [38, "#34e3c4,#0ea5a0"], [31, "#5eead4,#14b8a6"]].map(([h, g], i) => <div key={i} style={{ width: 10, height: h, borderRadius: 4, background: `linear-gradient(180deg,${g})` }} />)}
      </div>
      <div style={{ position: "absolute", top: -9, right: -9, width: 32, height: 32, borderRadius: 999, background: "linear-gradient(150deg,#fbbf24,#f59e0b)", boxShadow: "0 6px 14px -3px rgba(245,158,11,.7)", display: "flex", alignItems: "center", justifyContent: "center" }}><span className="num" style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>₺</span></div>
    </div>
  );

  const features = [
    { t: "Yapay zeka ile ekle", d: "Konuşarak veya yazarak saniyede işle", p: "M12 3l1.6 4.6L18 9l-4.4 1.4L12 15l-1.6-4.6L6 9l4.4-1.4L12 3z" },
    { t: "Kart & taksit takibi", d: "Borcunu, ekstreni, taksitlerini gör", p: "M2.5 8.5h19M3 6h18a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z" },
    { t: "Hedefler & bütçe", d: "Tasarruf et, limitlerini aşma", p: "M3 17l6-6 4 4 8-8M16 7h5v5" },
  ];

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 100, background: "var(--bg)", display: "flex", justifyContent: "center", overflow: "hidden", animation: "bt-sp-up .4s ease both" }}>
      <div style={{ position: "absolute", top: "-10%", left: "-15%", width: "70%", height: "44%", background: "radial-gradient(circle, rgba(45,224,192,.26), transparent 66%)", filter: "blur(44px)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "-12%", right: "-18%", width: "72%", height: "46%", background: "radial-gradient(circle, rgba(139,123,255,.22), transparent 68%)", filter: "blur(46px)", pointerEvents: "none" }} />

      <div style={{ position: "relative", width: "100%", maxWidth: 440, display: "flex", flexDirection: "column", padding: "0 24px", color: "var(--text)" }}>
        {step === 0 ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: 26 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, textAlign: "center" }}>
              <Logo />
              <div>
                <div className="num" style={{ fontSize: 27, fontWeight: 700, letterSpacing: "-.02em" }}>Hoş geldin</div>
                <div style={{ fontSize: 14.5, color: "var(--sub)", marginTop: 6, lineHeight: 1.5 }}>Paranı akıllıca yönetmen için her şey hazır.</div>
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {features.map((f) => (
                <div key={f.t} style={cardBox({ padding: "14px 16px", display: "flex", alignItems: "center", gap: 14, borderRadius: 18 })}>
                  <div style={{ width: 42, height: 42, borderRadius: 13, flexShrink: 0, background: "rgba(45,224,192,.14)", color: PRIMARY, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={f.p} /></svg>
                  </div>
                  <div>
                    <div style={{ fontSize: 14.5, fontWeight: 700 }}>{f.t}</div>
                    <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 2 }}>{f.d}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <button onClick={() => setStep(1)} style={{ background: "linear-gradient(135deg,#2DE0C0,#14b8a6)", color: "#06201c", border: "none", borderRadius: 16, padding: 16, fontSize: 15.5, fontWeight: 800, cursor: "pointer", fontFamily: "inherit", boxShadow: "0 14px 30px -10px rgba(45,224,192,.6)" }}>Başla</button>
              <button onClick={onClose} style={{ background: "transparent", color: "var(--muted)", border: "none", padding: 6, fontWeight: 600, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" }}>Şimdilik geç</button>
            </div>
          </div>
        ) : step === 1 ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: 22 }}>
            <div style={{ textAlign: "center" }}>
              <div className="num" style={{ fontSize: 25, fontWeight: 700, letterSpacing: "-.02em" }}>Aylık gelirin?</div>
              <div style={{ fontSize: 14, color: "var(--sub)", marginTop: 6, lineHeight: 1.5 }}>İlk kaydını oluşturalım. Sonra istediğin zaman değiştirebilirsin.</div>
            </div>
            <div style={cardBox({ display: "flex", alignItems: "baseline", gap: 10, padding: "18px 20px", borderRadius: 20 })}>
              <span style={{ fontSize: 28, fontWeight: 600, color: "var(--muted)" }}>₺</span>
              <input type="text" inputMode="decimal" value={income} onChange={(e) => setIncome(e.target.value)} placeholder="0" autoFocus className="num" style={{ flex: 1, minWidth: 0, background: "transparent", border: "none", outline: "none", fontSize: 40, fontWeight: 700, color: "var(--text)" }} />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <button onClick={() => setStep(2)} style={{ background: "linear-gradient(135deg,#2DE0C0,#14b8a6)", color: "#06201c", border: "none", borderRadius: 16, padding: 16, fontSize: 15.5, fontWeight: 800, cursor: "pointer", fontFamily: "inherit", boxShadow: "0 14px 30px -10px rgba(45,224,192,.6)" }}>Devam</button>
              <button onClick={() => setStep(2)} style={{ background: "transparent", color: "var(--muted)", border: "none", padding: 6, fontWeight: 600, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" }}>Gelir eklemeden devam et</button>
            </div>
          </div>
        ) : (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap: 18 }}>
            <div style={{ textAlign: "center" }}>
              <div className="num" style={{ fontSize: 24, fontWeight: 700, letterSpacing: "-.02em" }}>Aylık bütçe hedefin</div>
              <div style={{ fontSize: 14, color: "var(--sub)", marginTop: 6, lineHeight: 1.5 }}>İstersen birkaç kategoriye limit koy. Boş bırakabilirsin.</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {budgetCats.map((c) => (
                <div key={c.key} style={cardBox({ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderRadius: 16 })}>
                  <div style={{ width: 36, height: 36, borderRadius: 11, flexShrink: 0, background: c.color + "22", color: c.color, display: "flex", alignItems: "center", justifyContent: "center" }}><CatIcon k={c.key} size={19} /></div>
                  <div style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>{c.label}</div>
                  <span style={{ fontSize: 15, color: "var(--muted)", fontWeight: 600 }}>₺</span>
                  <input type="text" inputMode="decimal" value={lims[c.key] || ""} onChange={(e) => setLim(c.key, e.target.value)} placeholder="0" className="num" style={{ width: 92, background: "var(--card2)", border: "1px solid var(--border)", borderRadius: 10, padding: "9px 11px", fontSize: 15, fontWeight: 700, color: "var(--text)", outline: "none", textAlign: "right" }} />
                </div>
              ))}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <button onClick={finish} style={{ background: "linear-gradient(135deg,#2DE0C0,#14b8a6)", color: "#06201c", border: "none", borderRadius: 16, padding: 16, fontSize: 15.5, fontWeight: 800, cursor: "pointer", fontFamily: "inherit", boxShadow: "0 14px 30px -10px rgba(45,224,192,.6)" }}>Tamamla</button>
              <button onClick={finish} style={{ background: "transparent", color: "var(--muted)", border: "none", padding: 6, fontWeight: 600, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" }}>Bütçesiz devam et</button>
            </div>
          </div>
        )}

        <div style={{ display: "flex", justifyContent: "center", gap: 7, paddingBottom: 28 }}>
          {[0, 1, 2].map((i) => <span key={i} style={{ width: i === step ? 22 : 7, height: 7, borderRadius: 99, background: i === step ? PRIMARY : "var(--line)", transition: "width .25s ease" }} />)}
        </div>
      </div>
    </div>
  );
}

// ---------- FATURALAR ----------
function Faturalar({ recurring, due, expCats, catOf, onAdd, onUpdate, onRemove, onPay }) {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("fatura");
  const [day, setDay] = useState("1");
  const [rtype, setRtype] = useState("expense");

  const add = () => {
    const a = parseAmount(amount); const d = parseInt(day, 10);
    if (!name.trim() || !a || a <= 0) return;
    onAdd({ name: name.trim(), amount: a, category: rtype === "income" ? "maas" : category, day: Math.min(28, Math.max(1, d || 1)), active: true, type: rtype });
    setName(""); setAmount(""); setDay("1"); setRtype("expense"); setAdding(false);
  };
  const sabitGider = recurring.filter((r) => r.active && (r.type || "expense") === "expense").reduce((a, r) => a + r.amount, 0);
  const sabitGelir = recurring.filter((r) => r.active && r.type === "income").reduce((a, r) => a + r.amount, 0);
  const dueSorted = [...due].sort((a, b) => (a.paid - b.paid) || (a.day - b.day));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
      <div style={{ display: "flex", gap: 12 }}>
        <div style={cardBox({ flex: 1, padding: "15px 16px" })}>
          <div style={{ fontSize: 11.5, color: "var(--sub)", fontWeight: 600 }}>Sabit gider</div>
          <div style={{ fontSize: 20, fontWeight: 800, fontVariantNumeric: "tabular-nums", marginTop: 3 }}>{fmt(sabitGider)}</div>
        </div>
        <div style={cardBox({ flex: 1, padding: "15px 16px" })}>
          <div style={{ fontSize: 11.5, color: "var(--sub)", fontWeight: 600 }}>Sabit gelir</div>
          <div style={{ fontSize: 20, fontWeight: 800, fontVariantNumeric: "tabular-nums", marginTop: 3, color: "#16A34A" }}>{fmt(sabitGelir)}</div>
        </div>
      </div>
      <div style={{ fontSize: 12.5, color: "var(--muted)", padding: "0 4px", lineHeight: 1.5 }}>"İşle" dersen o ay için kayıt oluşur (gider veya gelir).</div>

      {dueSorted.map((r) => {
        const c = catOf(r.category); const inc = r.type === "income";
        return (
          <div key={r.id} style={cardBox({ borderRadius: 18, padding: "15px 16px", boxShadow: "var(--cardShadowSm)", opacity: r.active ? 1 : 0.5 })}>
            <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
              <span style={{ width: 9, height: 9, borderRadius: 999, background: inc ? "#16A34A" : c.color, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14.5, fontWeight: 600 }}>{r.name}{inc && <span style={{ color: "#16A34A", fontSize: 11.5, fontWeight: 700 }}> · gelir</span>}</div>
                <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>Her ayın {r.day}. günü · {fmt(r.amount)}</div>
              </div>
              {r.paid ? <span style={{ fontSize: 12.5, fontWeight: 700, color: "#16A34A" }}>✓ İşlendi</span>
                : r.active ? <button onClick={() => onPay(r)} style={{ background: inc ? "#16A34A" : PRIMARY, color: "#fff", border: "none", borderRadius: 11, padding: "9px 17px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>İşle</button>
                  : <span style={{ fontSize: 12, color: "var(--muted)", fontWeight: 600 }}>pasif</span>}
            </div>
            <div style={{ display: "flex", gap: 18, marginTop: 11, paddingLeft: 20 }}>
              <button onClick={() => onUpdate({ ...r, active: !r.active })} style={{ background: "transparent", border: "none", color: "var(--sub)", fontSize: 12.5, fontWeight: 600, cursor: "pointer", padding: 0, fontFamily: "inherit" }}>{r.active ? "Duraklat" : "Aktifleştir"}</button>
              <button onClick={() => onRemove(r.id)} style={{ background: "transparent", border: "none", color: "#E11D48", fontSize: 12.5, fontWeight: 600, cursor: "pointer", padding: 0, fontFamily: "inherit" }}>Sil</button>
            </div>
          </div>
        );
      })}

      {adding ? (
        <div style={cardBox({ display: "flex", flexDirection: "column", gap: 12 })}>
          <div style={{ display: "flex", gap: 6, background: "var(--card2)", padding: 4, borderRadius: 12 }}>
            {[["expense", "Gider"], ["income", "Gelir"]].map(([k, l]) => <button key={k} onClick={() => setRtype(k)} style={{ flex: 1, padding: 8, borderRadius: 9, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 12.5, fontFamily: "inherit", background: rtype === k ? PRIMARY : "transparent", color: rtype === k ? "#fff" : "var(--sub)" }}>{l}</button>)}
          </div>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder={rtype === "income" ? "Gelir adı (örn. Maaş)" : "Fatura adı (örn. Kira)"} style={fieldStyle} autoFocus />
          <div style={{ display: "flex", gap: 10 }}>
            <input type="text" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Tutar ₺" style={{ ...fieldStyle, flex: 2, minWidth: 0 }} />
            <input type="number" value={day} onChange={(e) => setDay(e.target.value)} placeholder="Gün" style={{ ...fieldStyle, flex: 1, minWidth: 0, textAlign: "center" }} />
          </div>
          {rtype === "expense" && <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{expCats.map((c) => <Chip key={c.key} small label={c.label} active={category === c.key} color={c.color} onClick={() => setCategory(c.key)} />)}</div>}
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={add} style={{ flex: 1, background: PRIMARY, color: "#fff", border: "none", borderRadius: 14, padding: 14, fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Ekle</button>
            <button onClick={() => setAdding(false)} style={{ background: "var(--chip)", color: "var(--sub)", border: "none", borderRadius: 14, padding: "14px 20px", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>İptal</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setAdding(true)} style={{ background: "var(--card)", color: PRIMARY, border: "1.5px dashed var(--addDash)", borderRadius: 16, padding: 15, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>＋ Tekrar eden kayıt ekle</button>
      )}
    </div>
  );
}

// ---------- AYARLAR ----------
function Ayarlar({ theme, setTheme, budgets, onSetLimit, byCatMap, expCats, customCats, onAddCat, onDelCat, onSuggest, exportData, onImport, onReplayOnboard, bioOn, onToggleBio, onReport }) {
  const [tab, setTab] = useState("butce");
  const [rmsg, setRmsg] = useState(null);
  const isLight = theme !== "dark";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
      <div style={{ fontSize: 11.5, color: "var(--muted)", fontWeight: 700, letterSpacing: ".06em", padding: "2px 4px 0" }}>GÖRÜNÜM</div>
      <Seg options={[["light", "Açık"], ["dark", "Koyu"]]} value={isLight ? "light" : "dark"} onChange={setTheme} />
      <button onClick={onReplayOnboard} style={{ background: "var(--card)", color: "var(--sub)", border: "none", borderRadius: 14, padding: 12, fontWeight: 600, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit", boxShadow: "var(--cardShadowSm)" }}>Kurulum sihirbazını gör</button>
      {IS_NATIVE && onToggleBio && (
        <button onClick={onToggleBio} style={{ display: "flex", alignItems: "center", gap: 12, background: "var(--card)", border: "1px solid var(--border)", borderRadius: 14, padding: "12px 14px", cursor: "pointer", fontFamily: "inherit", textAlign: "left" }}>
          <div style={{ width: 36, height: 36, borderRadius: 11, flexShrink: 0, background: "rgba(45,224,192,.14)", color: PRIMARY, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></svg>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)" }}>Uygulama kilidi</div>
            <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 1 }}>Açılışta parmak izi / yüz ile kilit</div>
          </div>
          <div style={{ width: 44, height: 26, borderRadius: 99, background: bioOn ? PRIMARY : "var(--chip)", position: "relative", transition: "background .2s", flexShrink: 0 }}>
            <div style={{ position: "absolute", top: 3, left: bioOn ? 21 : 3, width: 20, height: 20, borderRadius: 99, background: "#fff", transition: "left .2s", boxShadow: "0 1px 3px rgba(0,0,0,.3)" }} />
          </div>
        </button>
      )}
      {onReport && (
        <div>
          <button onClick={async () => { const r = await onReport(); if (r) setRmsg(r); }} style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", background: "var(--card)", border: "1px solid var(--border)", borderRadius: 14, padding: "12px 14px", cursor: "pointer", fontFamily: "inherit", textAlign: "left" }}>
            <div style={{ width: 36, height: 36, borderRadius: 11, flexShrink: 0, background: "rgba(139,123,255,.16)", color: "#8B7BFF", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" /><path d="M14 3v5h5" /><path d="M9 13h6M9 17h4" /></svg>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)" }}>Aylık rapor (PDF)</div>
              <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 1 }}>Bu ayın özetini PDF olarak indir / paylaş</div>
            </div>
          </button>
          {rmsg && <div style={{ fontSize: 12.5, color: rmsg.ok ? PRIMARY : "#FB7185", padding: "6px 4px 0" }}>{rmsg.message}</div>}
        </div>
      )}

      <div style={{ marginTop: 4 }}><Seg sm options={[["butce", "Bütçe"], ["kategori", "Kategoriler"], ["yedek", "Yedek"]]} value={tab} onChange={setTab} /></div>

      {tab === "butce" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
          <div style={{ fontSize: 12.5, color: "var(--muted)", padding: "0 4px", lineHeight: 1.5 }}>Kategori başına aylık gider limiti.</div>
          <button onClick={onSuggest} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: PRIMARY + "14", color: PRIMARY, border: "1px solid " + PRIMARY + "33", borderRadius: 14, padding: 13, fontWeight: 700, fontSize: 13.5, cursor: "pointer", fontFamily: "inherit" }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3l1.6 4.6L18 9l-4.4 1.4L12 15l-1.6-4.6L6 9l4.4-1.4L12 3z" /></svg>
            Akıllı limit önerisi (son 3 ay ortalaması)
          </button>
          {expCats.map((c) => <BudgetRow key={c.key} cat={c} limit={budgets[c.key] || 0} spent={byCatMap[c.key] || 0} onCommit={onSetLimit} />)}
        </div>
      )}
      {tab === "kategori" && <KategoriYonet expCats={expCats} customCats={customCats} onAddCat={onAddCat} onDelCat={onDelCat} />}
      {tab === "yedek" && <Yedekleme exportData={exportData} onImport={onImport} />}
    </div>
  );
}

function BudgetRow({ cat, limit, spent, onCommit }) {
  const [val, setVal] = useState(limit ? String(limit) : "");
  useEffect(() => { setVal(limit ? String(limit) : ""); }, [limit]);
  const p = limit ? Math.min(100, (spent / limit) * 100) : 0;
  const ov = !!limit && spent > limit;
  return (
    <div style={cardBox({ borderRadius: 18, padding: "15px 16px", boxShadow: "var(--cardShadowSm)" })}>
      <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
        <span style={{ width: 10, height: 10, borderRadius: 3, background: cat.color, flexShrink: 0 }} />
        <span style={{ flex: 1, fontSize: 14, fontWeight: 600 }}>{cat.label}</span>
        <input type="number" inputMode="decimal" value={val} onChange={(e) => setVal(e.target.value)} onBlur={() => onCommit(cat.key, val)} placeholder="limit" style={{ width: 94, background: "var(--card2)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 11, padding: "9px 11px", fontSize: 14, textAlign: "right", outline: "none", fontFamily: "inherit" }} />
      </div>
      {limit > 0 && (
        <div style={{ marginTop: 11 }}>
          <div style={{ height: 7, borderRadius: 999, background: "var(--line)", overflow: "hidden" }}><div style={{ width: `${p}%`, height: "100%", borderRadius: 999, background: ov ? "#E11D48" : cat.color }} /></div>
          <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 6, fontVariantNumeric: "tabular-nums" }}>{fmt(spent)} / {fmt(limit)}</div>
        </div>
      )}
    </div>
  );
}

function KategoriYonet({ expCats, customCats, onAddCat, onDelCat }) {
  const [name, setName] = useState("");
  const [color, setColor] = useState(CAT_PALETTE[0]);
  const customKeys = new Set(customCats.map((c) => c.key));
  const add = () => { if (!name.trim()) return; onAddCat(name.trim(), color); setName(""); };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
      <div style={{ fontSize: 12.5, color: "var(--muted)", padding: "0 4px", lineHeight: 1.5 }}>Kendi gider kategorilerini ekle. Hazır kategoriler silinemez.</div>
      <div style={cardBox()}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {expCats.map((c) => (
            <div key={c.key} style={{ display: "flex", alignItems: "center", gap: 7, background: "var(--chip)", borderRadius: 999, padding: "7px 8px 7px 12px" }}>
              <span style={{ width: 9, height: 9, borderRadius: 3, background: c.color }} />
              <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text)" }}>{c.label}</span>
              {customKeys.has(c.key) && <button onClick={() => onDelCat(c.key)} style={{ background: "transparent", border: "none", color: "var(--muted)", fontSize: 16, lineHeight: 1, cursor: "pointer", padding: "0 2px", fontFamily: "inherit" }}>×</button>}
            </div>
          ))}
        </div>
      </div>
      <div style={cardBox({ display: "flex", flexDirection: "column", gap: 12 })}>
        <div style={{ fontSize: 14, fontWeight: 700 }}>Yeni kategori</div>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Kategori adı (örn. Abonelikler)" style={fieldStyle} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{CAT_PALETTE.map((col) => <button key={col} onClick={() => setColor(col)} style={{ width: 30, height: 30, borderRadius: 9, background: col, border: color === col ? "3px solid var(--text)" : "3px solid transparent", cursor: "pointer" }} />)}</div>
        <button onClick={add} disabled={!name.trim()} style={{ background: name.trim() ? PRIMARY : "var(--chip)", color: name.trim() ? "#fff" : "var(--muted)", border: "none", borderRadius: 14, padding: 13, fontWeight: 700, fontSize: 15, cursor: name.trim() ? "pointer" : "default", fontFamily: "inherit" }}>Kategori ekle</button>
      </div>
    </div>
  );
}

function Yedekleme({ exportData, onImport }) {
  const json = JSON.stringify({ ...exportData, exportDate: new Date().toISOString() }, null, 2);
  const [importText, setImportText] = useState("");
  const [msg, setMsg] = useState(null);
  const [last, setLast] = useState(() => { try { return localStorage.getItem("bt-last-backup"); } catch { return null; } });
  const markBackup = () => { try { const t = String(Date.now()); localStorage.setItem("bt-last-backup", t); setLast(t); } catch {} };
  const warn = !last || (Date.now() - Number(last)) > 7 * 86400000;
  const backupAgo = (() => { if (!last) return null; const days = Math.floor((Date.now() - Number(last)) / 86400000); if (days <= 0) return "bugün"; if (days === 1) return "dün"; return `${days} gün önce`; })();
  const dl = (data, fname, mime) => { try { const b = new Blob([data], { type: mime }); const u = URL.createObjectURL(b); const a = document.createElement("a"); a.href = u; a.download = fname; a.click(); URL.revokeObjectURL(u); markBackup(); setMsg({ ok: true, text: "Dosya indirildi." }); } catch { setMsg({ ok: false, text: "İndirme bu önizlemede engelli — JSON'u kopyala." }); } };
  const downloadJson = () => dl(json, `butce-yedek-${todayISO()}.json`, "application/json");
  const downloadCsv = () => { const head = "Tarih;Tip;Kategori;Açıklama;Tutar"; const rows = (exportData.transactions || []).map((t) => [t.date, t.type === "income" ? "Gelir" : "Gider", t.category, (t.description || "").replace(/;/g, ","), t.amount].join(";")); dl("\uFEFF" + [head, ...rows].join("\n"), `butce-${todayISO()}.csv`, "text/csv"); };
  const copy = async () => { try { await navigator.clipboard.writeText(json); markBackup(); setMsg({ ok: true, text: "Panoya kopyalandı." }); } catch { setMsg({ ok: false, text: "Kopyalama engelli — metni elle seç." }); } };
  const doImport = async () => { try { await onImport(importText); setMsg({ ok: true, text: "Veriler geri yüklendi." }); setImportText(""); } catch { setMsg({ ok: false, text: "Geçersiz JSON." }); } };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
      <div style={cardBox({ display: "flex", alignItems: "center", gap: 12, border: warn ? "1px solid rgba(245,158,11,.4)" : "1px solid var(--border)" })}>
        <div style={{ width: 38, height: 38, borderRadius: 12, flexShrink: 0, background: warn ? "rgba(245,158,11,.15)" : "rgba(45,224,192,.14)", color: warn ? "#f59e0b" : PRIMARY, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13.5, fontWeight: 700 }}>{last ? `Son yedek: ${backupAgo}` : "Henüz yedek alınmadı"}</div>
          <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 1 }}>{last ? "Düzenli yedek almanı öneririz." : "Verini kaybetmemek için bir yedek al."}</div>
        </div>
      </div>
      <div style={cardBox()}>
        <div style={{ fontSize: 14.5, fontWeight: 700 }}>Dışa aktar</div>
        <div style={{ fontSize: 12.5, color: "var(--muted)", margin: "4px 0 12px", lineHeight: 1.5 }}>JSON tam yedek, CSV ise Excel/Sheets için.</div>
        <textarea readOnly value={json} onFocus={(e) => e.target.select()} style={{ width: "100%", height: 100, background: "var(--card2)", color: "var(--sub)", border: "1px solid var(--border)", borderRadius: 14, padding: 12, fontSize: 11, fontFamily: "ui-monospace, monospace", resize: "none", outline: "none" }} />
        <div style={{ display: "flex", gap: 10, marginTop: 11 }}>
          <button onClick={downloadJson} style={{ flex: 1, background: PRIMARY, color: "#fff", border: "none", borderRadius: 13, padding: 13, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>JSON indir</button>
          <button onClick={downloadCsv} style={{ flex: 1, background: "var(--chip)", color: "var(--text)", border: "none", borderRadius: 13, padding: 13, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>CSV indir</button>
          <button onClick={copy} style={{ background: "var(--chip)", color: "var(--text)", border: "none", borderRadius: 13, padding: "13px 16px", fontWeight: 600, fontSize: 14, cursor: "pointer", fontFamily: "inherit" }}>Kopyala</button>
        </div>
      </div>
      <div style={cardBox()}>
        <div style={{ fontSize: 14.5, fontWeight: 700 }}>İçe aktar</div>
        <div style={{ fontSize: 12.5, color: "var(--muted)", margin: "4px 0 12px", lineHeight: 1.5 }}>Yedek JSON'unu yapıştır. Mevcut veriler değiştirilir.</div>
        <textarea value={importText} onChange={(e) => setImportText(e.target.value)} placeholder='{ "transactions": [...] }' style={{ width: "100%", height: 80, background: "var(--card2)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 14, padding: 12, fontSize: 12, fontFamily: "ui-monospace, monospace", resize: "none", outline: "none" }} />
        <button onClick={doImport} disabled={!importText.trim()} style={{ width: "100%", marginTop: 11, background: importText.trim() ? "#F59E0B" : "var(--chip)", color: importText.trim() ? "#fff" : "var(--muted)", border: "none", borderRadius: 13, padding: 13, fontWeight: 700, fontSize: 14, cursor: importText.trim() ? "pointer" : "default", fontFamily: "inherit" }}>Geri yükle</button>
      </div>
      {msg && <div style={{ fontSize: 13, fontWeight: 600, textAlign: "center", color: msg.ok ? "#16A34A" : "#E11D48" }}>{msg.text}</div>}
    </div>
  );
}

function Empty({ text, sub, icon, pad = 40 }) {
  return (
    <div style={{ textAlign: "center", padding: `${pad}px 24px`, background: "var(--card)", border: "1px dashed var(--dash)", borderRadius: 20 }}>
      <div style={{ width: 52, height: 52, borderRadius: 16, margin: "0 auto 12px", background: "var(--chip)", color: "var(--muted)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        {icon || <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 6h14l1.5 6v6a1 1 0 0 1-1 1H4.5a1 1 0 0 1-1-1v-6z" /><path d="M3.5 12h4l1.5 2.5h6L16.5 12h4" /></svg>}
      </div>
      <div style={{ fontSize: 14, fontWeight: 600, color: "var(--sub)" }}>{text}</div>
      {sub && <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function LockScreen({ onUnlock }) {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 150, background: "var(--bg)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 22, color: "var(--text)" }}>
      <div style={{ width: 84, height: 84, borderRadius: 26, background: "rgba(45,224,192,.14)", color: PRIMARY, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></svg>
      </div>
      <div style={{ textAlign: "center" }}>
        <div className="num" style={{ fontSize: 22, fontWeight: 700 }}>Kilitli</div>
        <div style={{ fontSize: 14, color: "var(--sub)", marginTop: 6 }}>Devam etmek için kimliğini doğrula.</div>
      </div>
      <button onClick={onUnlock} style={{ background: "linear-gradient(135deg,#2DE0C0,#14b8a6)", color: "#06201c", border: "none", borderRadius: 16, padding: "14px 28px", fontSize: 15, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>Kilidi aç</button>
    </div>
  );
}

function Rapor({ ym, byCat, totalIncome, totalExpense, net, onClose }) {
  const expTotal = byCat.reduce((a, c) => a + c.value, 0) || 1;
  const print = () => { try { window.print(); } catch {} };
  return (
    <Sheet title="Aylık rapor" onClose={onClose}>
      <div id="bt-print">
        <div style={{ textAlign: "center", marginBottom: 16 }}>
          <div className="num" style={{ fontSize: 20, fontWeight: 800 }}>Bütçe Raporu</div>
          <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 2 }}>{MONTHS[ym.m]} {ym.y}</div>
        </div>
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          {[["Gelir", totalIncome, "#16A34A"], ["Gider", totalExpense, "#E11D48"], ["Net", net, net >= 0 ? "#16A34A" : "#E11D48"]].map(([l, v, col]) => (
            <div key={l} style={cardBox({ flex: 1, padding: "12px 10px", textAlign: "center" })}>
              <div style={{ fontSize: 11.5, color: "var(--muted)", fontWeight: 600 }}>{l}</div>
              <div className="num" style={{ fontSize: 16, fontWeight: 800, marginTop: 4, color: col }}>{fmt(v)}</div>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 13.5, fontWeight: 700, margin: "4px 2px 8px" }}>Kategoriye göre gider</div>
        <div style={cardBox({ padding: "6px 14px" })}>
          {byCat.length === 0 ? <div style={{ padding: 16, textAlign: "center", color: "var(--muted)", fontSize: 13 }}>Bu ay gider yok.</div> :
            byCat.map((c, i) => (
              <div key={c.key} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderTop: i ? "1px solid var(--line)" : "none" }}>
                <span style={{ width: 10, height: 10, borderRadius: 3, background: c.color, flexShrink: 0 }} />
                <span style={{ flex: 1, fontSize: 13.5, fontWeight: 600 }}>{c.label}</span>
                <span style={{ fontSize: 12.5, color: "var(--muted)", width: 42, textAlign: "right" }}>%{Math.round((c.value / expTotal) * 100)}</span>
                <span className="num" style={{ fontSize: 13.5, fontWeight: 700, width: 92, textAlign: "right" }}>{fmt(c.value)}</span>
              </div>
            ))}
        </div>
      </div>
      <button onClick={print} style={{ marginTop: 16, width: "100%", background: "linear-gradient(135deg,#2DE0C0,#14b8a6)", color: "#06201c", border: "none", borderRadius: 14, padding: 14, fontWeight: 800, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Yazdır / PDF olarak kaydet</button>
    </Sheet>
  );
}

function Splash({ leaving, onSkip }) {
  return (
    <div onClick={onSkip} style={{ position: "fixed", inset: 0, zIndex: 200, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", cursor: "pointer", overflow: "hidden", background: "radial-gradient(120% 80% at 50% 18%, #0f2f2a 0%, #0a201d 42%, #06120f 100%)", opacity: leaving ? 0 : 1, transform: leaving ? "scale(1.05)" : "scale(1)", transition: "opacity .5s ease, transform .5s ease" }}>
      <div style={{ position: "absolute", top: "8%", left: "50%", transform: "translateX(-50%)", width: "120%", height: "46%", background: "radial-gradient(circle, rgba(45,224,192,.28), transparent 64%)", filter: "blur(46px)", animation: "bt-pulse 4.5s ease-in-out infinite", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "-6%", left: "-12%", width: "60%", height: "38%", background: "radial-gradient(circle, rgba(20,184,166,.22), transparent 68%)", filter: "blur(48px)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "-8%", right: "-14%", width: "54%", height: "34%", background: "radial-gradient(circle, rgba(56,189,248,.14), transparent 70%)", filter: "blur(50px)", pointerEvents: "none" }} />

      <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 42 }}>
        <div style={{ position: "absolute", width: 150, height: 150, borderRadius: 42, border: "1.5px solid rgba(45,224,192,.5)", animation: "bt-sp-ring 2.6s ease-out infinite" }} />
        <div style={{ position: "absolute", width: 150, height: 150, borderRadius: 42, border: "1.5px solid rgba(45,224,192,.5)", animation: "bt-sp-ring 2.6s ease-out infinite 1.3s" }} />
        <div style={{ position: "relative", width: 132, height: 132, borderRadius: 38, background: "linear-gradient(150deg,#ffffff,#eef6f4)", boxShadow: "0 26px 60px -18px rgba(0,0,0,.6), 0 0 0 1px rgba(255,255,255,.4) inset, 0 0 50px -6px rgba(45,224,192,.5)", display: "flex", alignItems: "center", justifyContent: "center", animation: "bt-sp-tile .9s cubic-bezier(.2,.85,.25,1) both" }}>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 11, height: 62 }}>
            {[[38, "#34e3c4,#14b8a6", ".5s"], [62, "#34e3c4,#0ea5a0", ".64s"], [50, "#5eead4,#14b8a6", ".78s"]].map(([h, g, d], i) => (
              <div key={i} style={{ width: 17, height: h, borderRadius: 7, background: `linear-gradient(180deg,${g})`, transformOrigin: "bottom", animation: `bt-sp-bar .6s cubic-bezier(.2,.9,.3,1) ${d} both` }} />
            ))}
          </div>
          <div style={{ position: "absolute", top: -12, right: -12, width: 48, height: 48, borderRadius: 999, background: "linear-gradient(150deg,#fbbf24,#f59e0b)", boxShadow: "0 8px 20px -4px rgba(245,158,11,.7), 0 0 0 4px #0a201d", display: "flex", alignItems: "center", justifyContent: "center", animation: "bt-sp-coin .7s cubic-bezier(.2,.85,.25,1) .9s both" }}>
            <span className="num" style={{ fontSize: 24, fontWeight: 700, color: "#fff", lineHeight: 1 }}>₺</span>
          </div>
        </div>
      </div>

      <div style={{ position: "relative", textAlign: "center", animation: "bt-sp-up .7s ease 1.05s both" }}>
        <div className="num" style={{ fontSize: 36, fontWeight: 700, color: "#fff", letterSpacing: "-.02em" }}>Bütçe Takibi</div>
        <div style={{ fontSize: 15, fontWeight: 500, color: "rgba(167,243,224,.85)", marginTop: 8, letterSpacing: ".01em" }}>Paranı akıllıca yönet</div>
      </div>

      <div style={{ position: "absolute", bottom: 64, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center", gap: 20, animation: "bt-sp-up .7s ease 1.3s both" }}>
        <div style={{ width: 158, height: 4, borderRadius: 99, background: "rgba(255,255,255,.12)", overflow: "hidden" }}>
          <div style={{ height: "100%", borderRadius: 99, background: "linear-gradient(90deg,#2DE0C0,#5eead4)", boxShadow: "0 0 12px rgba(45,224,192,.8)", animation: "bt-sp-prog 2.4s cubic-bezier(.4,0,.2,1) both" }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 9, animation: "bt-sp-tap 1.8s ease-in-out infinite" }}>
          <span style={{ display: "flex", color: "rgba(255,255,255,.55)" }}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11.5V5.5a1.5 1.5 0 0 1 3 0v6" /><path d="M12 11V4.5a1.5 1.5 0 0 1 3 0V11" /><path d="M15 11V6a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-2a5 5 0 0 1-3.6-1.5L4 16a1.6 1.6 0 0 1 2.3-2.2L8 15.3" /></svg></span>
          <span style={{ fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,.6)", letterSpacing: ".02em" }}>Geçmek için dokun</span>
        </div>
      </div>
    </div>
  );
}

function ConfirmSheet({ text, onClose, onYes, yesLabel = "Sil", danger = true }) {
  return (
    <Sheet title="Emin misin?" onClose={onClose}>
      <div style={{ fontSize: 14, color: "var(--sub)", lineHeight: 1.5, marginBottom: 16 }}>{text}</div>
      <div style={{ display: "flex", gap: 10 }}>
        <button onClick={onClose} style={{ flex: 1, background: "var(--chip)", color: "var(--text)", border: "none", borderRadius: 14, padding: 14, fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Vazgeç</button>
        <button onClick={onYes} style={{ flex: 1, background: danger ? "#E11D48" : PRIMARY, color: "#fff", border: "none", borderRadius: 14, padding: 14, fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>{yesLabel}</button>
      </div>
    </Sheet>
  );
}

function AISheet({ expCats, catOf, onAdd, onClose }) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState(null);
  const [error, setError] = useState(null);
  const [listening, setListening] = useState(false);
  const recRef = useRef(null);
  const SR = typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);
  const voiceSupported = !!SR;
  const examples = ["Bugün 250 TL market alışverişi", "2000 TL nakit geldi", "Dün kartla 80 lira kahve", "Kira için 18000 ödedim"];
  const VALID_EXP = new Set(expCats.map((c) => c.key));

  useEffect(() => () => { try { recRef.current && recRef.current.stop(); } catch {} }, []);

  const toggleVoice = () => {
    if (!voiceSupported) return;
    if (listening) { try { recRef.current && recRef.current.stop(); } catch {} return; }
    try {
      const rec = new SR();
      recRef.current = rec;
      rec.lang = "tr-TR";
      rec.interimResults = true;
      rec.continuous = false;
      let base = text ? text + " " : "";
      rec.onresult = (e) => {
        let s = "";
        for (let i = 0; i < e.results.length; i++) s += e.results[i][0].transcript;
        setText((base + s).trim());
      };
      rec.onerror = (e) => { setListening(false); setError(e.error === "not-allowed" ? "Mikrofon izni verilmedi." : "Ses tanıma çalışmadı, yazarak deneyebilirsin."); };
      rec.onend = () => setListening(false);
      setError(null); setListening(true); rec.start();
    } catch { setListening(false); setError("Ses tanıma bu ortamda kullanılamıyor."); }
  };

  const normalize = (raw) => {
    const list = Array.isArray(raw) ? raw : raw && Array.isArray(raw.transactions) ? raw.transactions : raw ? [raw] : [];
    return list.map((o) => {
      const type = o.type === "income" ? "income" : "expense";
      let category = String(o.category || "");
      if (type === "expense" && !VALID_EXP.has(category)) category = "diger";
      if (type === "income" && !INC_CATS.some((c) => c.key === category)) category = "gelir_diger";
      const amount = Math.abs(parseAmount(o.amount));
      const date = /^\d{4}-\d{2}-\d{2}$/.test(o.date) ? o.date : todayISO();
      const method = type === "expense" ? (o.method === "nakit" ? "nakit" : "kart") : undefined;
      return { type, amount, category, description: String(o.description || "").slice(0, 60), date, ...(method ? { method } : {}) };
    }).filter((o) => o.amount > 0);
  };

  const analyze = async () => {
    if (!text.trim() || loading) return;
    setLoading(true); setError(null); setItems(null);
    const expList = expCats.map((c) => `${c.key} (${c.label})`).join(", ");
    const incList = INC_CATS.map((c) => `${c.key} (${c.label})`).join(", ");
    const prompt = `Bugünün tarihi: ${todayISO()}. Kullanıcının Türkçe metnini bir veya daha fazla finansal işleme çevir.
Gider kategorileri (key): ${expList}.
Gelir kategorileri (key): ${incList}.
Kurallar:
- SADECE geçerli bir JSON dizisi döndür. Markdown, açıklama veya başka metin yazma.
- Her öğe: {"type":"expense"|"income","amount":<sayı>,"category":"<yukarıdaki key'lerden biri>","description":"<kısa Türkçe açıklama>","date":"YYYY-MM-DD","method":"kart"|"nakit"}
- amount sadece sayı olsun (ondalık için nokta), sembol yazma.
- Gelir mi gider mi olduğunu metinden çıkar.
- Gider ise ödeme yöntemini çıkar: "kredi kartı/kart/banka" -> "kart", "nakit/elden" -> "nakit", belirsizse "kart". Gelirde method yazma.
- Uygun kategori yoksa gider için "diger", gelir için "gelir_diger".
- Göreli tarihleri bugüne göre çöz; tarih yoksa bugünü kullan.
Metin: """${text}"""`;
    try {
      const res = await fetch(AI_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 1000, messages: [{ role: "user", content: prompt }] }),
      });
      const data = await res.json();
      const out = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("").replace(/```json|```/g, "").trim();
      const parsed = normalize(JSON.parse(out));
      if (parsed.length === 0) setError('İşlem çıkarılamadı. Daha açık yaz (örn. "bugün 200 TL market").');
      else setItems(parsed);
    } catch {
      setError("Çözümlenemedi. Bağlantıyı kontrol edip tekrar dene.");
    } finally { setLoading(false); }
  };

  const commit = () => { items.forEach((it) => onAdd(it)); onClose(); };
  const removeItem = (i) => setItems((p) => p.filter((_, idx) => idx !== i));

  return (
    <Sheet title="Yapay zeka ile ekle" onClose={onClose}>
      {!items ? (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ fontSize: 13, color: "var(--sub)", lineHeight: 1.5 }}>Ne yaptığını yaz ya da söyle; otomatik gelir/gider olarak ekleyeyim.</div>
          <div style={{ position: "relative" }}>
            <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={'örn. "Bugün kredi kartıyla 1000 TL market alışverişi yaptım"'} autoFocus style={{ ...fieldStyle, height: 84, resize: "none", paddingRight: 52 }} />
            {voiceSupported && (
              <button onClick={toggleVoice} aria-label="Sesle yaz" style={{ position: "absolute", right: 8, bottom: 8, width: 38, height: 38, borderRadius: 12, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", background: listening ? "#E11D48" : PRIMARY, color: "#fff", boxShadow: listening ? "0 0 0 4px rgba(225,29,72,.18)" : "none" }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0" /><line x1="12" y1="18" x2="12" y2="22" /></svg>
              </button>
            )}
          </div>
          {listening && <div style={{ fontSize: 12.5, color: "#E11D48", fontWeight: 600, display: "flex", alignItems: "center", gap: 7 }}><span style={{ width: 8, height: 8, borderRadius: 999, background: "#E11D48", animation: "bt-float 1.2s ease-in-out infinite" }} />Dinleniyor… konuş, bitince mikrofona tekrar dokun</div>}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {examples.map((ex) => <button key={ex} onClick={() => setText(ex)} style={{ background: "var(--chip)", color: "var(--sub)", border: "none", borderRadius: 999, padding: "7px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>{ex}</button>)}
          </div>
          {error && <div style={{ fontSize: 13, color: "#E11D48", fontWeight: 600 }}>{error}</div>}
          <button onClick={analyze} disabled={!text.trim() || loading} style={{ background: text.trim() && !loading ? "linear-gradient(135deg,#2DE0C0,#38BDF8)" : "var(--chip)", color: text.trim() && !loading ? "#fff" : "var(--muted)", border: "none", borderRadius: 14, padding: 15, fontWeight: 700, fontSize: 15, cursor: text.trim() && !loading ? "pointer" : "default", fontFamily: "inherit" }}>{loading ? "Çözümleniyor…" : "Çözümle"}</button>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ fontSize: 13, color: "var(--sub)" }}>Şunları ekleyeceğim — onayla:</div>
          {items.map((it, i) => {
            const c = catOf(it.category); const inc = it.type === "income";
            return (
              <div key={i} style={cardBox({ padding: "13px 15px", display: "flex", alignItems: "center", gap: 11 })}>
                <span style={{ width: 9, height: 9, borderRadius: 999, background: inc ? "#16A34A" : c.color, flexShrink: 0 }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{it.description || c.label}</div>
                  <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>{inc ? "Gelir" : "Gider"} · {c.label}{it.method ? " · " + (it.method === "nakit" ? "Nakit" : "Kart") : ""} · {new Date(it.date).toLocaleDateString("tr-TR", { day: "numeric", month: "short" })}</div>
                </div>
                <div style={{ fontSize: 15, fontWeight: 700, color: inc ? "#16A34A" : "var(--text)", fontVariantNumeric: "tabular-nums" }}>{inc ? "+" : "−"}{fmt(it.amount)}</div>
                <button onClick={() => removeItem(i)} style={{ background: "transparent", border: "none", color: "var(--muted)", fontSize: 19, cursor: "pointer", fontFamily: "inherit" }}>×</button>
              </div>
            );
          })}
          <div style={{ display: "flex", gap: 10, marginTop: 2 }}>
            <button onClick={() => setItems(null)} style={{ background: "var(--chip)", color: "var(--sub)", border: "none", borderRadius: 14, padding: "14px 18px", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>Geri</button>
            <button onClick={commit} disabled={items.length === 0} style={{ flex: 1, background: items.length ? PRIMARY : "var(--chip)", color: items.length ? "#fff" : "var(--muted)", border: "none", borderRadius: 14, padding: 14, fontWeight: 700, fontSize: 15, cursor: items.length ? "pointer" : "default", fontFamily: "inherit" }}>{items.length} işlem ekle</button>
          </div>
        </div>
      )}
    </Sheet>
  );
}
